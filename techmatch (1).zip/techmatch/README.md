# TechMatch - smart technician recommendation platform

Recommends the best technician for a job based on skill, availability, location and price, and explains every ranking.

- Frontend: React + Vite + Tailwind. Backend: Node.js + Express. Database: PostgreSQL.
- One deployable service: Express serves the built React app, so Railway needs only ONE service plus a Postgres database.
- All demo data is fictional.

## What is included (and what is not)

Included: registration/login (JWT, bcrypt), role-based access (hiring manager, technician, admin), job creation with mandatory/preferred requirements, technician profiles (self-reported vs admin-verified), the matching engine (eligibility filters, weighted score, categories, explanations, tie-breakers, missing-data handling, 14 automated tests), results page with search/sort/filter, shortlist, side-by-side comparison, adjustable weights, invitations (accept / decline / ask a question / withdraw), in-app notifications, reviews (only after an accepted invitation), dashboards for all three roles, admin settings for weights and thresholds, technician verification, audit log, 10 fictional technicians and 2 demo jobs.

Not included: email/WhatsApp sending (notifications are in-app only and labelled as such), AI interview screening, social-profile scraping (it conflicts with most platforms' terms of service), file uploads (portfolio is links), map provider (distances use a built-in city list and the haversine formula).

## Folder structure

```
package.json            root scripts used by Railway (build + start)
backend/
  src/server.js         REST API + serves the frontend build
  src/db.js             schema creation + fictional seed data (runs automatically on start)
  src/matching-engine.js
  test/matching.test.js
  .env.example
frontend/
  src/pages/            Landing, Auth, HiringDashboard, JobForm, JobMatches, TechDashboard, TechProfile, Notifications, Admin
  src/components/       Layout, ui helpers
```

## Demo logins (password for all: `password`)

| Role | Email |
|---|---|
| Hiring manager | john@example.com |
| Technician | sarah@example.com |
| Admin | admin@example.com |

## Run locally

1. Install Node.js 18+ and a Postgres database. Quickest way with Docker:
   ```bash
   docker run --name techmatch-db -e POSTGRES_PASSWORD=password -e POSTGRES_DB=techmatch -p 5432:5432 -d postgres:16
   ```
2. Backend:
   ```bash
   cd backend
   npm install
   cp .env.example .env      # on Windows: copy .env.example .env
   npm run dev               # http://localhost:5000  (tables and demo data are created automatically)
   ```
3. Frontend (second terminal):
   ```bash
   cd frontend
   npm install
   npm run dev               # http://localhost:3000  (proxies /api to port 5000)
   ```
4. Open http://localhost:3000 and log in as john@example.com / password, open "Build REST API and admin dashboard" and click "View matches".
5. Run the algorithm tests: `cd backend && npm test` (no database needed).

## Push to GitHub (repo KHOJ-)

1. Delete the old files in the repo root, including the two misnamed `gemini-code-*.json` files (they confuse the builder).
2. Copy everything from this folder (including `.gitignore`) into the repo root, so that `package.json`, `backend/` and `frontend/` sit at the top level.
3. In a terminal inside the repo:
   ```bash
   git add .
   git commit -m "Add TechMatch source code"
   git push origin main
   ```
4. Refresh GitHub and confirm you can see `package.json`, `backend/` and `frontend/` at the top level.

## Deploy on Railway (one service + Postgres)

1. In your Railway project, delete the failed service (or keep it, we reuse it in step 3).
2. Click **New** > **Database** > **Add PostgreSQL**. Wait until it shows as running.
3. Click **New** > **GitHub Repo** > choose `KHOJ-` (or open your existing service). Leave **Root Directory empty**.
4. Open the service > **Variables** and add:
   - `DATABASE_URL` = `${{Postgres.DATABASE_URL}}` (use the "Add reference" option so Railway links the database)
   - `JWT_SECRET` = a long random string (generate with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`)
   - `NODE_ENV` = `production`
5. Open **Settings** > **Networking** > **Generate Domain**.
6. Redeploy. Railway detects the root `package.json`, runs `npm run build` (installs and builds the frontend, installs backend packages) and `npm start`.
7. Open **Deploy Logs**. You should see `Seeding fictional demo data...` (first run only) and `TechMatch listening on ...`.
8. Open the generated domain and log in with a demo account.

To start with an empty database (no demo users), add the variable `SEED_DEMO_DATA` = `false` before the first deploy.

### Using Supabase instead of Railway Postgres

Set `DATABASE_URL` to the Supabase connection string (Project Settings > Database > Connection string > URI) and add `PGSSL` = `true`.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Railway: "Railpack failed to prepare the build" | `package.json` is not at the repo root. Check the GitHub file list. |
| Deploy log: "DATABASE_URL is not set" | Add the variable reference from step 4. |
| Deploy log: "Database initialisation failed" | Wrong connection string, or add `PGSSL=true` for Supabase. |
| Blank page after deploy | Open Build Logs and check that `vite build` finished; then redeploy. |
| Login says email or password incorrect | Demo users exist only if the first start had `SEED_DEMO_DATA` unset or `true`. |
| `npm install` fails locally | Use Node 18 or newer (`node --version`). |

## How the matching works

1. **Eligibility (mandatory).** A technician is excluded from recommendations if they lack a mandatory skill or level, lack a mandatory certification, cannot finish before the deadline, are outside the travel limit (not applied to remote jobs), exceed a hard budget limit, or are not accepting jobs. Excluded technicians appear under "Near matches" with the reason.
2. **Score (0-100).** Each criterion is scored 0-100, then weighted: skills 30, availability 20, location 15, price 15, experience 10, certifications 5, reviews 5 (editable by the admin, and per job by the employer).
3. **Missing data is never a silent zero or a perfect score.** A criterion with unknown data is left out, the remaining weights are rescaled (shown on each card), and a warning plus a data-confidence label is displayed. A single review is smoothed so one 5-star rating is not treated as conclusive.
4. **Price** compares the technician's expected total cost for this job (hourly rate x job hours, or their fixed price) with the job budget.
5. **Categories:** 80+ Highly Recommended, 60-79.99 Moderately Recommended, below 60 Low Priority. Ties are broken by availability, then price fit, then number of reviews.

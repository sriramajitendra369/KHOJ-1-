import { Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import { useAuth, homeFor } from './auth';
import Landing from './pages/Landing';
import Auth from './pages/Auth';
import HiringDashboard from './pages/HiringDashboard';
import JobForm from './pages/JobForm';
import JobMatches from './pages/JobMatches';
import TechDashboard from './pages/TechDashboard';
import TechProfile from './pages/TechProfile';
import Notifications from './pages/Notifications';
import Admin from './pages/Admin';

function Protected({ roles, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to={homeFor(user)} replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Auth mode="login" />} />
        <Route path="/register" element={<Auth mode="register" />} />
        <Route path="/dashboard" element={<Protected roles={['hiring']}><HiringDashboard /></Protected>} />
        <Route path="/jobs/new" element={<Protected roles={['hiring']}><JobForm /></Protected>} />
        <Route path="/jobs/:id/matches" element={<Protected roles={['hiring', 'admin']}><JobMatches /></Protected>} />
        <Route path="/tech" element={<Protected roles={['technician']}><TechDashboard /></Protected>} />
        <Route path="/profile" element={<Protected roles={['technician']}><TechProfile /></Protected>} />
        <Route path="/notifications" element={<Protected><Notifications /></Protected>} />
        <Route path="/admin" element={<Protected roles={['admin']}><Admin /></Protected>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}

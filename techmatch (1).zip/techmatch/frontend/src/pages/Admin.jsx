import { useEffect, useState } from 'react';
import { api } from '../api';
import { Alert, Badge, Spinner, Stat, useLoad } from '../components/ui';

const LABELS = { skills: 'Skills', availability: 'Availability', location: 'Location', price: 'Price', experience: 'Experience', certifications: 'Certifications', reviews: 'Reviews' };

export default function Admin() {
  const { data, error, loading, reload } = useLoad(() => api.get('/admin/stats'));
  const [w, setW] = useState(null);
  const [t, setT] = useState(null);
  const [msg, setMsg] = useState({ kind: 'success', text: '' });

  useEffect(() => { if (data) { setW(data.settings.weights); setT(data.settings.thresholds); } }, [data]);
  if (loading && !data) return <Spinner />;
  if (error) return <Alert>{error}</Alert>;
  if (!w) return <Spinner />;
  const total = Object.values(w).reduce((a, b) => a + Number(b || 0), 0);

  const saveSettings = async () => {
    try { await api.put('/admin/settings', { weights: w, thresholds: t }); setMsg({ kind: 'success', text: 'Matching settings saved. New rankings use them immediately.' }); reload(); }
    catch (e) { setMsg({ kind: 'error', text: e.message }); }
  };
  const verify = async (id, verified) => { await api.post(`/admin/verify/${id}`, { verified }); reload(); };
  const s = data.stats;

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-navy-900">Administration</h1>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-6">
        <Stat label="Users" value={s.users} tone="navy" /><Stat label="Technicians" value={s.technicians} /><Stat label="Employers" value={s.employers} />
        <Stat label="Jobs" value={s.jobs} tone="teal" /><Stat label="Invitations" value={s.invitations} tone="amber" /><Stat label="Accepted" value={s.accepted} tone="teal" />
      </div>

      <section className="card space-y-3">
        <h2 className="font-semibold text-navy-900">Matching weights</h2>
        <p className="text-sm text-slate-500">Weights are relative (current total {total}); the engine rescales them to 100%.</p>
        {msg.text && <Alert kind={msg.kind}>{msg.text}</Alert>}
        <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-4">
          {Object.keys(LABELS).map((k) => (
            <div key={k}><label className="label" htmlFor={k}>{LABELS[k]}</label><input id={k} type="number" min="0" className="input" value={w[k]} onChange={(e) => setW({ ...w, [k]: e.target.value })} /></div>
          ))}
          <div><label className="label" htmlFor="th">Highly Recommended from</label><input id="th" type="number" className="input" value={t.high} onChange={(e) => setT({ ...t, high: e.target.value })} /></div>
          <div><label className="label" htmlFor="tm">Moderately Recommended from</label><input id="tm" type="number" className="input" value={t.moderate} onChange={(e) => setT({ ...t, moderate: e.target.value })} /></div>
        </div>
        <button className="btn btn-primary" onClick={saveSettings}>Save matching settings</button>
      </section>

      <section className="card">
        <h2 className="mb-3 font-semibold text-navy-900">Technician verification</h2>
        <div className="space-y-2">
          {data.technicians.map((x) => (
            <div key={x.id} className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2">
              <div><p className="font-medium">{x.name} <span className="text-sm text-slate-500">{x.email}</span></p><p className="text-sm text-slate-500">{x.headline || 'No headline'} · {x.city || 'No city'}</p></div>
              <div className="flex items-center gap-2"><Badge tone={x.verified ? 'accepted' : 'pending'}>{x.verified ? 'Verified' : 'Unverified'}</Badge>
                <button className="btn btn-outline" onClick={() => verify(x.id, !x.verified)}>{x.verified ? 'Remove verification' : 'Verify'}</button></div>
            </div>
          ))}
        </div>
      </section>

      <section className="card">
        <h2 className="mb-3 font-semibold text-navy-900">Audit log</h2>
        <ul className="space-y-1 text-sm text-slate-600">{data.logs.map((l) => <li key={l.id}>{new Date(l.created_at).toLocaleString('en-IN')} · {l.action}</li>)}</ul>
      </section>
    </div>
  );
}

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';
import { Alert, useLoad } from '../components/ui';

const CATEGORIES = ['Software', 'Networking', 'Electrical', 'Hardware repair', 'Security systems', 'Mobile apps', 'Design', 'Other'];

export default function JobForm() {
  const nav = useNavigate();
  const meta = useLoad(() => api.get('/meta'));
  const [f, setF] = useState({
    title: '', description: '', category: 'Software', work_type: 'onsite', city: 'Hyderabad', max_distance_km: 50,
    min_experience: '', deadline: '', duration_hours: '', budget_min: '', budget_max: '', budget_hard: false,
    payment_model: 'hourly', conditions: '',
  });
  const [skills, setSkills] = useState([{ name: '', min_level: 3, mandatory: true }]);
  const [certs, setCerts] = useState([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const upd = (list, setList, i, patch) => setList(list.map((x, j) => (j === i ? { ...x, ...patch } : x)));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const job = await api.post('/jobs', { ...f, required_skills: skills, certifications: certs });
      nav(`/jobs/${job.id}/matches`);
    } catch (err) {
      setError(err.message);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="mx-auto max-w-3xl space-y-6">
      <h1 className="text-2xl font-bold text-navy-900">Post a job</h1>
      <Alert>{error}</Alert>

      <section className="card space-y-4">
        <h2 className="font-semibold text-navy-900">The work</h2>
        <div>
          <label className="label" htmlFor="title">Job title</label>
          <input id="title" className="input" value={f.title} onChange={set('title')} required />
        </div>
        <div>
          <label className="label" htmlFor="desc">Description</label>
          <textarea id="desc" className="input" rows={3} value={f.description} onChange={set('description')} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="cat">Category</label>
            <select id="cat" className="input" value={f.category} onChange={set('category')}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
          </div>
          <div>
            <label className="label" htmlFor="wt">Work arrangement</label>
            <select id="wt" className="input" value={f.work_type} onChange={set('work_type')}>
              <option value="onsite">On-site</option><option value="hybrid">Hybrid</option><option value="remote">Remote</option>
            </select>
          </div>
          {f.work_type !== 'remote' && (
            <>
              <div>
                <label className="label" htmlFor="city">Job location</label>
                <select id="city" className="input" value={f.city} onChange={set('city')}>{(meta.data?.cities || ['Hyderabad']).map((c) => <option key={c}>{c}</option>)}</select>
              </div>
              <div>
                <label className="label" htmlFor="md">Maximum travel distance (km)</label>
                <input id="md" type="number" min="0" className="input" value={f.max_distance_km} onChange={set('max_distance_km')} />
              </div>
            </>
          )}
        </div>
      </section>

      <section className="card space-y-3">
        <h2 className="font-semibold text-navy-900">Skills needed</h2>
        <p className="text-sm text-slate-500">Mandatory skills are must-haves: technicians without them are filtered out. Untick "Mandatory" to make a skill a preference only.</p>
        <datalist id="skill-list">{(meta.data?.skills || []).map((s) => <option key={s} value={s} />)}</datalist>
        {skills.map((s, i) => (
          <div key={i} className="flex flex-wrap items-center gap-2">
            <input aria-label="Skill name" list="skill-list" className="input w-48" placeholder="Skill, e.g. Node.js" value={s.name} onChange={(e) => upd(skills, setSkills, i, { name: e.target.value })} />
            <select aria-label="Minimum level" className="input w-40" value={s.min_level} onChange={(e) => upd(skills, setSkills, i, { min_level: Number(e.target.value) })}>
              {[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>Level {n}+ of 5</option>)}
            </select>
            <label className="flex items-center gap-1 text-sm"><input type="checkbox" checked={s.mandatory} onChange={(e) => upd(skills, setSkills, i, { mandatory: e.target.checked })} /> Mandatory</label>
            {skills.length > 1 && <button type="button" className="btn btn-outline" onClick={() => setSkills(skills.filter((_, j) => j !== i))}>Remove</button>}
          </div>
        ))}
        <button type="button" className="btn btn-outline" onClick={() => setSkills([...skills, { name: '', min_level: 3, mandatory: false }])}>Add a skill</button>

        <div className="grid gap-4 pt-2 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="exp">Minimum relevant experience (years)</label>
            <input id="exp" type="number" min="0" step="0.5" className="input" value={f.min_experience} onChange={set('min_experience')} />
          </div>
        </div>
        <h3 className="pt-2 text-sm font-semibold text-slate-700">Certifications</h3>
        {certs.map((c, i) => (
          <div key={i} className="flex flex-wrap items-center gap-2">
            <input aria-label="Certification name" className="input w-64" placeholder="Certification name" value={c.name} onChange={(e) => upd(certs, setCerts, i, { name: e.target.value })} />
            <label className="flex items-center gap-1 text-sm"><input type="checkbox" checked={c.mandatory} onChange={(e) => upd(certs, setCerts, i, { mandatory: e.target.checked })} /> Mandatory</label>
            <button type="button" className="btn btn-outline" onClick={() => setCerts(certs.filter((_, j) => j !== i))}>Remove</button>
          </div>
        ))}
        <button type="button" className="btn btn-outline" onClick={() => setCerts([...certs, { name: '', mandatory: false }])}>Add a certification</button>
      </section>

      <section className="card space-y-4">
        <h2 className="font-semibold text-navy-900">Schedule and budget</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="dl">Deadline</label>
            <input id="dl" type="date" className="input" value={f.deadline} onChange={set('deadline')} />
          </div>
          <div>
            <label className="label" htmlFor="dh">Estimated duration (hours)</label>
            <input id="dh" type="number" min="1" className="input" value={f.duration_hours} onChange={set('duration_hours')} required />
          </div>
          <div>
            <label className="label" htmlFor="pm">Payment model</label>
            <select id="pm" className="input" value={f.payment_model} onChange={set('payment_model')}>
              <option value="hourly">Hourly</option><option value="fixed">Fixed price</option><option value="negotiable">Negotiable</option>
            </select>
          </div>
          <div />
          <div>
            <label className="label" htmlFor="bmin">Total budget, minimum (₹)</label>
            <input id="bmin" type="number" min="0" className="input" value={f.budget_min} onChange={set('budget_min')} />
          </div>
          <div>
            <label className="label" htmlFor="bmax">Total budget, maximum (₹)</label>
            <input id="bmax" type="number" min="0" className="input" value={f.budget_max} onChange={set('budget_max')} />
          </div>
        </div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.budget_hard} onChange={set('budget_hard')} /> The maximum is a hard limit (filter out technicians who would cost more)</label>
        <div>
          <label className="label" htmlFor="cond">Additional conditions</label>
          <textarea id="cond" className="input" rows={2} value={f.conditions} onChange={set('conditions')} />
        </div>
      </section>

      <button className="btn btn-primary" disabled={busy}>{busy ? 'Finding technicians...' : 'Post job and see matches'}</button>
    </form>
  );
}

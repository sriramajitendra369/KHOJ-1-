import { Link } from 'react-router-dom';
import { useState } from 'react';
import { api } from '../api';
import { Alert, Badge, Empty, Spinner, Stat, fmtDate, useLoad } from '../components/ui';

function ReviewBox({ inv, onDone }) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [err, setErr] = useState('');
  const send = async () => {
    try {
      await api.post('/reviews', { job_id: inv.job_id, technician_id: inv.technician_id, rating, comment });
      onDone();
    } catch (e) { setErr(e.message); }
  };
  return (
    <div className="mt-2 flex flex-wrap items-center gap-2">
      <select className="input w-auto" value={rating} onChange={(e) => setRating(Number(e.target.value))} aria-label="Rating">
        {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} / 5</option>)}
      </select>
      <input className="input w-56" placeholder="Short comment (optional)" value={comment} onChange={(e) => setComment(e.target.value)} />
      <button className="btn btn-outline" onClick={send}>Submit review</button>
      {err && <span className="text-sm text-red-700">{err}</span>}
    </div>
  );
}

export default function HiringDashboard() {
  const stats = useLoad(() => api.get('/dashboard'));
  const jobs = useLoad(() => api.get('/jobs'));
  const invs = useLoad(() => api.get('/invitations'));
  const [msg, setMsg] = useState('');

  const withdraw = async (id) => {
    if (!window.confirm('Withdraw this invitation?')) return;
    try { await api.post(`/invitations/${id}/withdraw`); invs.reload(); stats.reload(); } catch (e) { setMsg(e.message); }
  };
  const setStatus = async (id, status) => { await api.put(`/jobs/${id}/status`, { status }); jobs.reload(); stats.reload(); };

  const s = stats.data || {};
  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold text-navy-900">Your hiring dashboard</h1>
        <Link to="/jobs/new" className="btn btn-primary">Post a job</Link>
      </div>
      <Alert>{msg || stats.error}</Alert>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-6">
        <Stat label="Jobs created" value={s.jobs} tone="navy" />
        <Stat label="Open jobs" value={s.open_jobs} tone="teal" />
        <Stat label="Shortlisted" value={s.shortlisted} />
        <Stat label="Pending invitations" value={s.pending} tone="amber" />
        <Stat label="Accepted" value={s.accepted} tone="teal" />
        <Stat label="Declined" value={s.declined} tone="navy" />
      </div>

      <section>
        <h2 className="mb-3 text-lg font-semibold text-navy-900">Your jobs</h2>
        {jobs.loading ? <Spinner /> : !jobs.data?.length ? (
          <Empty title="No jobs yet">Post your first job and see ranked technicians right away.</Empty>
        ) : (
          <div className="space-y-3">
            {jobs.data.map((j) => (
              <div key={j.id} className="card flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-semibold text-navy-900">{j.title} <Badge tone={j.status}>{j.status}</Badge></p>
                  <p className="text-sm text-slate-500">{j.work_type}{j.city ? ` in ${j.city}` : ''} · deadline {fmtDate(j.deadline)} · {j.shortlist_count} shortlisted · {j.invitation_count} invited</p>
                </div>
                <div className="flex gap-2">
                  {j.status === 'open' && <button className="btn btn-outline" onClick={() => setStatus(j.id, 'closed')}>Close job</button>}
                  {j.status !== 'open' && <button className="btn btn-outline" onClick={() => setStatus(j.id, 'open')}>Reopen job</button>}
                  <Link to={`/jobs/${j.id}/matches`} className="btn btn-primary">View matches</Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="mb-3 text-lg font-semibold text-navy-900">Invitations</h2>
        {invs.loading ? <Spinner /> : !invs.data?.length ? (
          <Empty title="No invitations sent">Open a job's matches and invite a technician.</Empty>
        ) : (
          <div className="space-y-3">
            {invs.data.map((i) => (
              <div key={i.id} className="card">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p><span className="font-semibold">{i.technician_name}</span> for {i.title} <Badge>{i.status}</Badge></p>
                  {(i.status === 'pending' || i.status === 'clarification') && <button className="btn btn-danger" onClick={() => withdraw(i.id)}>Withdraw</button>}
                </div>
                {i.response_note && <p className="mt-1 text-sm text-slate-600">Their note: {i.response_note}</p>}
                {i.status === 'accepted' && <p className="mt-1 text-sm text-slate-600">Contact: {i.technician_email}</p>}
                {i.status === 'declined' && <p className="mt-1 text-sm text-slate-500">Declined. <Link className="text-indigo-700 underline" to={`/jobs/${i.job_id}/matches`}>Shortlist or invite another candidate</Link></p>}
                {i.status === 'accepted' && !i.reviewed && <ReviewBox inv={i} onDone={invs.reload} />}
                {i.status === 'accepted' && i.reviewed > 0 && <p className="mt-1 text-sm text-teal-700">You reviewed this technician.</p>}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

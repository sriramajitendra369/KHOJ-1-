import { useEffect } from 'react';
import { api } from '../api';
import { Empty, Spinner, useLoad } from '../components/ui';

export default function Notifications() {
  const { data, loading } = useLoad(() => api.get('/notifications'));
  useEffect(() => { api.post('/notifications/read-all').catch(() => {}); }, []);
  return (
    <div className="mx-auto max-w-2xl space-y-3">
      <h1 className="text-2xl font-bold text-navy-900">Notifications</h1>
      {loading ? <Spinner /> : !data?.length ? <Empty title="Nothing new">Invitation updates and reviews will appear here.</Empty> : data.map((n) => (
        <div key={n.id} className={`card ${n.read ? '' : 'border-indigo-300'}`}>
          <p className="font-semibold text-navy-900">{n.title}</p>
          {n.body && <p className="text-sm text-slate-600">{n.body}</p>}
          <p className="mt-1 text-xs text-slate-400">{new Date(n.created_at).toLocaleString('en-IN')}</p>
        </div>
      ))}
    </div>
  );
}

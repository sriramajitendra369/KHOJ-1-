import { Link } from 'react-router-dom';
import { useAuth, homeFor } from '../auth';

const WEIGHTS = [['Skills', 30], ['Availability', 20], ['Location', 15], ['Price', 15], ['Experience', 10], ['Certifications', 5], ['Reviews', 5]];

export default function Landing() {
  const { user } = useAuth();
  return (
    <div className="grid items-center gap-10 py-6 md:grid-cols-2">
      <div>
        <h1 className="text-4xl font-bold leading-tight text-navy-900 md:text-5xl">Hire the technician who can actually do the job.</h1>
        <p className="mt-5 max-w-prose text-lg text-slate-600">
          Describe the work once. TechMatch checks skills, schedule, distance and price against every technician, drops anyone who misses a must-have, and shows exactly why each person is ranked where they are.
        </p>
        <div className="mt-7 flex flex-wrap gap-3">
          {user ? (
            <Link to={homeFor(user)} className="btn btn-primary">Go to your dashboard</Link>
          ) : (
            <>
              <Link to="/register" className="btn btn-primary">Create an account</Link>
              <Link to="/login" className="btn btn-outline">Log in with a demo account</Link>
            </>
          )}
        </div>
        <p className="mt-4 text-sm text-slate-500">Demo data is fictional. Demo logins: john@example.com (employer), sarah@example.com (technician), admin@example.com, password: password</p>
      </div>
      <div className="card">
        <p className="font-semibold text-navy-900">How every technician is scored</p>
        <p className="mt-1 text-sm text-slate-500">Must-haves filter first. Then these weights apply (employers can change them per job).</p>
        <div className="mt-4 space-y-3">
          {WEIGHTS.map(([k, w]) => (
            <div key={k}>
              <div className="flex justify-between text-sm"><span>{k}</span><span className="font-semibold">{w}%</span></div>
              <div className="mt-1 h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-indigo-600" style={{ width: `${w * 3}%` }} /></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

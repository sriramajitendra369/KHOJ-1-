import { Link } from 'react-router-dom';
import { useState } from 'react';
import { api } from '../api';
import { Alert, Badge, Empty, Spinner, Stat, fmtDate, inr, useLoad } from '../components/ui';

export default function TechDashboard() {
  const stats = useLoad(() => api.get('/dashboard'));
  const invs = useLoad(() => api.get('/invitations'));
  const [notes, setNotes] = useState({});
  const [msg, setMsg] = useState('');

  const respond = async (inv, status) => {
    if (status === 'clarification' && !(notes[inv.id] || '').trim()) { setMsg('Write your question in the note box first.'); return; }
    if (status === 'accepted' && !window.confirm('Accepting shares your email with the employer. Continue?')) return;
    try { await api.post(`/invitations/${inv.id}/respond`, { status, note: notes[inv.id] }); setMsg(''); invs.reload(); stats.reload(); } catch (e) { setMsg(e.message); }
  };
  const s = stats.data || {};
  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-navy-900">Your dashboard</h1>
      <Alert>{msg || stats.error}</Alert>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
        <Stat label="Profile complete (%)" value={s.completion} tone="teal" />
        <Stat label="Pending invitations" value={s.pending} tone="amber" />
        <Stat label="Accepted" value={s.accepted} tone="teal" />
        <Stat label="Declined" value={s.declined} tone="navy" />
        <Stat label={`Reviews${s.rating ? ` (avg ${s.rating.toFixed(1)})` : ''}`} value={s.reviews} />
      </div>
      {s.completion < 100 && <Alert kind="warn">A more complete profile ranks better and avoids "unknown data" warnings. <Link className="underline" to="/profile">Update your profile</Link></Alert>}
      <p className="text-sm text-slate-500">Account verification: {s.verified ? 'Verified by an administrator' : 'Not verified yet. Your details show as self-reported.'}</p>

      <section>
        <h2 className="mb-3 text-lg font-semibold text-navy-900">Job invitations</h2>
        {invs.loading ? <Spinner /> : !invs.data?.length ? <Empty title="No invitations yet">Keep your profile and availability up to date so employers can find you.</Empty> : (
          <div className="space-y-3">
            {invs.data.map((i) => (
              <div key={i.id} className="card">
                <p className="font-semibold text-navy-900">{i.title} <Badge>{i.status}</Badge></p>
                <p className="text-sm text-slate-500">From {i.owner_name} · {i.work_type}{i.job_city ? ` in ${i.job_city}` : ''} · deadline {fmtDate(i.deadline)} · {i.duration_hours} hours · budget {inr(i.budget_min)} to {inr(i.budget_max)}</p>
                {i.description && <p className="mt-2 text-sm">{i.description}</p>}
                {i.message && <p className="mt-2 text-sm italic text-slate-600">Message: {i.message}</p>}
                {(i.status === 'pending' || i.status === 'clarification') && (
                  <div className="mt-3 space-y-2">
                    <input className="input" placeholder="Optional note, or a question for the employer" value={notes[i.id] || ''} onChange={(e) => setNotes({ ...notes, [i.id]: e.target.value })} />
                    <div className="flex flex-wrap gap-2">
                      <button className="btn btn-teal" onClick={() => respond(i, 'accepted')}>Accept</button>
                      <button className="btn btn-danger" onClick={() => respond(i, 'declined')}>Decline</button>
                      <button className="btn btn-outline" onClick={() => respond(i, 'clarification')}>Ask a question</button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

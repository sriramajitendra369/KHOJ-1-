import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { BadgeCheck, ChevronDown, ChevronUp, Star } from 'lucide-react';
import { api } from '../api';
import { Alert, Badge, Bar, Empty, Spinner, inr, useLoad } from '../components/ui';

const LABELS = { skills: 'Skills', availability: 'Availability', location: 'Location', price: 'Price', experience: 'Experience', certifications: 'Certifications', reviews: 'Reviews' };
const SORTS = {
  score: ['Match score', (a, b) => b.score - a.score],
  price: ['Lowest price', (a, b) => (a.estimatedCost.amount ?? 1e12) - (b.estimatedCost.amount ?? 1e12)],
  experience: ['Most experience', (a, b) => (b.relevantYears ?? -1) - (a.relevantYears ?? -1)],
  distance: ['Nearest', (a, b) => (a.distanceKm ?? 1e9) - (b.distanceKm ?? 1e9)],
  rating: ['Highest rating', (a, b) => (b.rating ?? -1) - (a.rating ?? -1)],
  availability: ['Soonest available', (a, b) => (b.criteria.availability.score ?? -1) - (a.criteria.availability.score ?? -1)],
};

function TechCard({ t, shortlisted, invited, compared, onShortlist, onCompare, onInvite, near }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="card">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-lg font-semibold text-navy-900">
            {t.rank ? `#${t.rank} ` : ''}{t.name} {t.verified && <BadgeCheck size={16} className="inline text-teal-600" aria-label="Verified account" />}
          </p>
          <p className="text-sm text-slate-500">{t.headline || 'No headline'}{t.city ? ` · ${t.city}` : ''}</p>
        </div>
        <div className="text-right">
          <p className="text-3xl font-bold text-indigo-700">{Math.round(t.score)}%</p>
          {near ? <Badge tone="declined">Not eligible</Badge> : <Badge>{t.category}</Badge>}
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-sm text-slate-600">
        <span>Expected cost: <b>{inr(t.estimatedCost.amount)}</b></span>
        <span>{t.distanceKm !== null ? `${t.distanceKm} km away` : 'Distance n/a'}</span>
        <span>{t.relevantYears !== null ? `${t.relevantYears} yrs relevant` : 'Experience unknown'}</span>
        <span>{t.reviewCount ? <><Star size={13} className="mr-0.5 inline text-amber-500" />{t.rating.toFixed(1)} ({t.reviewCount})</> : 'No reviews yet'}</span>
        <span>Data confidence: {t.confidence}</span>
      </div>

      {near && <div className="mt-3"><Alert kind="warn">{t.failures.join(' · ')}</Alert></div>}
      {!near && t.warnings.length > 0 && <div className="mt-3"><Alert kind="warn">{t.warnings[0]}{t.warnings.length > 1 ? ` (+${t.warnings.length - 1} more)` : ''}</Alert></div>}

      <div className="mt-3 flex flex-wrap gap-1.5">
        {t.matchedSkills.map((s) => <span key={s.name} className="rounded bg-teal-100 px-2 py-0.5 text-xs text-teal-800">{s.name} L{s.level}</span>)}
        {t.missingPreferred.map((s) => <span key={s} className="rounded bg-slate-200 px-2 py-0.5 text-xs text-slate-600 line-through">{s}</span>)}
        {t.missingMandatory.map((s) => <span key={s} className="rounded bg-red-100 px-2 py-0.5 text-xs text-red-700 line-through">{s}</span>)}
      </div>

      <button className="mt-3 flex items-center gap-1 text-sm font-medium text-indigo-700" onClick={() => setOpen(!open)} aria-expanded={open}>
        {open ? <ChevronUp size={16} /> : <ChevronDown size={16} />} Why this ranking
      </button>
      {open && (
        <div className="mt-3 space-y-4 rounded-lg bg-slate-50 p-4">
          <p className="text-sm">{t.explanation}</p>
          <div className="grid gap-3 sm:grid-cols-2">
            {Object.keys(LABELS).map((k) => (
              <Bar key={k} label={`${LABELS[k]} (weight ${t.weightsUsed[k]}%)`} value={t.criteria[k].score} detail={t.criteria[k].detail} />
            ))}
          </div>
          <ul className="space-y-1 text-xs text-slate-600">{Object.keys(LABELS).map((k) => <li key={k}><b>{LABELS[k]}:</b> {t.criteria[k].detail}</li>)}</ul>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><p className="text-sm font-semibold text-teal-800">Strengths</p><ul className="list-disc pl-5 text-sm">{t.strengths.length ? t.strengths.map((s, i) => <li key={i}>{s}</li>) : <li>None stand out</li>}</ul></div>
            <div><p className="text-sm font-semibold text-red-800">Drawbacks</p><ul className="list-disc pl-5 text-sm">{t.drawbacks.length ? t.drawbacks.map((s, i) => <li key={i}>{s}</li>) : <li>None found</li>}</ul></div>
          </div>
        </div>
      )}

      {!near && (
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button className="btn btn-outline" onClick={onShortlist}>{shortlisted ? 'Remove from shortlist' : 'Shortlist'}</button>
          <label className="flex items-center gap-1 text-sm"><input type="checkbox" checked={compared} onChange={onCompare} /> Compare</label>
          {invited ? <Badge>{invited}</Badge> : <button className="btn btn-primary" onClick={onInvite}>Invite to job</button>}
        </div>
      )}
    </div>
  );
}

function Compare({ list, onClose }) {
  const rows = [
    ['Match score', (t) => `${Math.round(t.score)}% (${t.category})`],
    ...Object.keys(LABELS).map((k) => [`${LABELS[k]} score`, (t) => (t.criteria[k].score === null ? 'unknown / n/a' : Math.round(t.criteria[k].score))]),
    ['Expected cost', (t) => inr(t.estimatedCost.amount)],
    ['Vs budget max', (t) => (t.budgetDiff === null ? 'n/a' : t.budgetDiff >= 0 ? `${inr(t.budgetDiff)} under` : `${inr(-t.budgetDiff)} over`)],
    ['Distance', (t) => (t.distanceKm === null ? 'n/a' : `${t.distanceKm} km`)],
    ['Relevant experience', (t) => (t.relevantYears === null ? 'unknown' : `${t.relevantYears} yrs`)],
    ['Rating', (t) => (t.reviewCount ? `${t.rating.toFixed(1)} (${t.reviewCount} reviews)` : 'no reviews')],
    ['Completed projects', (t) => t.completedProjects ?? 'unknown'],
    ['Verified account', (t) => (t.verified ? 'Yes' : 'No (self-reported)')],
    ['Main drawback', (t) => t.drawbacks[0] || 'None found'],
  ];
  return (
    <div className="card overflow-x-auto">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold text-navy-900">Side-by-side comparison</h2>
        <button className="btn btn-outline" onClick={onClose}>Close comparison</button>
      </div>
      <table className="w-full min-w-[560px] text-sm">
        <thead><tr><th className="p-2 text-left" />{list.map((t) => <th key={t.technician_id} className="p-2 text-left text-navy-900">{t.name}</th>)}</tr></thead>
        <tbody>
          {rows.map(([label, fn]) => (
            <tr key={label} className="border-t border-slate-100">
              <td className="p-2 font-medium text-slate-600">{label}</td>
              {list.map((t) => <td key={t.technician_id} className="p-2">{fn(t)}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-3 text-sm text-slate-500">Trade-offs: a lower price often means fewer relevant years; a closer technician may have lower skill levels. Check the "Main drawback" row before choosing.</p>
    </div>
  );
}

export default function JobMatches() {
  const { id } = useParams();
  const [weights, setWeights] = useState(null);
  const { data, error, loading, reload } = useLoad(async () => {
    const qs = weights ? `?weights=${encodeURIComponent(JSON.stringify(weights))}` : '';
    const d = await api.get(`/jobs/${id}/matches${qs}`);
    return d;
  }, [id, weights]);
  const [sort, setSort] = useState('score');
  const [filter, setFilter] = useState('');
  const [category, setCategory] = useState('all');
  const [compare, setCompare] = useState([]);
  const [showCompare, setShowCompare] = useState(false);
  const [msg, setMsg] = useState({ kind: 'success', text: '' });
  const [draft, setDraft] = useState(null);

  const list = useMemo(() => {
    if (!data) return [];
    return data.eligible
      .filter((t) => (category === 'all' || t.category === category) && `${t.name} ${t.headline || ''} ${t.city || ''}`.toLowerCase().includes(filter.toLowerCase()))
      .sort(SORTS[sort][1]);
  }, [data, sort, filter, category]);

  if (loading && !data) return <Spinner label="Finding the best technicians..." />;
  if (error) return <Alert>{error}</Alert>;
  const shortlistSet = new Set(data.shortlist);
  const invitedMap = Object.fromEntries(data.invited.map((i) => [i.technician_id, i.status]));
  const current = draft || data.settings.weights;
  const all = [...data.eligible, ...data.nearMatches];
  const comparing = compare.map((cid) => all.find((t) => t.technician_id === cid)).filter(Boolean);

  const toggleShortlist = async (t) => {
    try { await api.post(`/jobs/${id}/shortlist`, { technician_id: t.technician_id }); reload(); } catch (e) { setMsg({ kind: 'error', text: e.message }); }
  };
  const invite = async (t) => {
    const note = window.prompt(`Invite ${t.name} to "${data.job.title}"?\n\nAdd an optional message (they will see your job details). Click Cancel to stop.`, '');
    if (note === null) return;
    try {
      await api.post('/invitations', { job_id: Number(id), technician_id: t.technician_id, message: note });
      setMsg({ kind: 'success', text: `Invitation sent to ${t.name}. They have been notified inside TechMatch (no email is sent in this version).` });
      reload();
    } catch (e) { setMsg({ kind: 'error', text: e.message }); }
  };
  const toggleCompare = (cid) => setCompare((c) => (c.includes(cid) ? c.filter((x) => x !== cid) : c.length >= 4 ? c : [...c, cid]));

  return (
    <div className="space-y-6">
      <div>
        <Link to="/dashboard" className="text-sm text-indigo-700 underline">Back to dashboard</Link>
        <h1 className="mt-1 text-2xl font-bold text-navy-900">{data.job.title}</h1>
        <p className="text-sm text-slate-500">{data.eligible.length} eligible technicians · {data.nearMatches.length} near matches (missing a must-have)</p>
      </div>
      {msg.text && <Alert kind={msg.kind}>{msg.text}</Alert>}

      <details className="card">
        <summary className="cursor-pointer font-semibold text-navy-900">Adjust what matters most</summary>
        <p className="mt-2 text-sm text-slate-500">Weights are relative. Must-haves still filter first, and no weight can override them.</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 md:grid-cols-3">
          {Object.keys(LABELS).map((k) => (
            <label key={k} className="text-sm">{LABELS[k]}: <b>{Math.round(current[k])}</b>
              <input type="range" min="0" max="50" className="w-full" value={current[k]} onChange={(e) => setDraft({ ...current, [k]: Number(e.target.value) })} />
            </label>
          ))}
        </div>
        <div className="mt-3 flex gap-2">
          <button className="btn btn-primary" onClick={() => setWeights(draft)} disabled={!draft}>Recalculate rankings</button>
          <button className="btn btn-outline" onClick={() => { setDraft(null); setWeights(null); }}>Reset to defaults</button>
        </div>
      </details>

      <div className="flex flex-wrap items-end gap-3">
        <div><label className="label" htmlFor="s">Search</label><input id="s" className="input w-56" placeholder="Name, headline or city" value={filter} onChange={(e) => setFilter(e.target.value)} /></div>
        <div><label className="label" htmlFor="so">Sort by</label><select id="so" className="input" value={sort} onChange={(e) => setSort(e.target.value)}>{Object.entries(SORTS).map(([k, v]) => <option key={k} value={k}>{v[0]}</option>)}</select></div>
        <div><label className="label" htmlFor="ca">Show</label><select id="ca" className="input" value={category} onChange={(e) => setCategory(e.target.value)}><option value="all">All eligible</option><option>Highly Recommended</option><option>Moderately Recommended</option><option>Low Priority</option></select></div>
        {comparing.length >= 2 && <button className="btn btn-teal" onClick={() => setShowCompare(true)}>Compare {comparing.length} selected</button>}
      </div>

      {showCompare && comparing.length >= 2 && <Compare list={comparing} onClose={() => setShowCompare(false)} />}

      <section className="space-y-4">
        {!list.length ? (
          <Empty title="No eligible technicians match these filters">Clear the filters, or mark a must-have as flexible by editing the job requirements and posting again. Near matches are listed below.</Empty>
        ) : list.map((t) => (
          <TechCard key={t.technician_id} t={t} shortlisted={shortlistSet.has(t.technician_id)} invited={invitedMap[t.technician_id]}
            compared={compare.includes(t.technician_id)} onShortlist={() => toggleShortlist(t)} onCompare={() => toggleCompare(t.technician_id)} onInvite={() => invite(t)} />
        ))}
      </section>

      {data.nearMatches.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-lg font-semibold text-navy-900">Near matches</h2>
          <p className="text-sm text-slate-500">These technicians fail at least one mandatory requirement, so they are not recommended. Their scores are shown for context.</p>
          {data.nearMatches.map((t) => <TechCard key={t.technician_id} t={t} near />)}
        </section>
      )}
    </div>
  );
}

import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth, homeFor } from '../auth';
import { Alert } from '../components/ui';

export default function Auth({ mode }) {
  const { login, register } = useAuth();
  const nav = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'hiring' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const isLogin = mode === 'login';
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const u = isLogin ? await login(form.email, form.password) : await register(form);
      nav(homeFor(u));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-md">
      <form onSubmit={submit} className="card space-y-4">
        <h1 className="text-2xl font-bold text-navy-900">{isLogin ? 'Log in' : 'Create your account'}</h1>
        <Alert>{error}</Alert>
        {!isLogin && (
          <>
            <div>
              <label className="label" htmlFor="name">Full name</label>
              <input id="name" className="input" value={form.name} onChange={set('name')} required />
            </div>
            <div>
              <label className="label" htmlFor="role">I am a</label>
              <select id="role" className="input" value={form.role} onChange={set('role')}>
                <option value="hiring">Hiring manager looking for a technician</option>
                <option value="technician">Technician looking for work</option>
              </select>
            </div>
          </>
        )}
        <div>
          <label className="label" htmlFor="email">Email</label>
          <input id="email" type="email" className="input" value={form.email} onChange={set('email')} required />
        </div>
        <div>
          <label className="label" htmlFor="password">Password</label>
          <input id="password" type="password" className="input" value={form.password} onChange={set('password')} minLength={6} required />
        </div>
        <button className="btn btn-primary w-full" disabled={busy}>{busy ? 'Please wait...' : isLogin ? 'Log in' : 'Create account'}</button>
        <p className="text-center text-sm text-slate-500">
          {isLogin ? <>New here? <Link className="text-indigo-700 underline" to="/register">Create an account</Link></> : <>Already registered? <Link className="text-indigo-700 underline" to="/login">Log in</Link></>}
        </p>
      </form>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { api } from '../api';
import { Alert, Spinner, useLoad } from '../components/ui';

export default function TechProfile() {
  const meta = useLoad(() => api.get('/meta'));
  const [f, setF] = useState(null);
  const [error, setError] = useState('');
  const [ok, setOk] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get('/technician/profile').then((p) => setF({
      ...p,
      skills: p.skills?.length ? p.skills : [{ name: '', level: 3, years: '' }],
      certifications: p.certifications || [],
      portfolio: (p.portfolio || []).join('\n'),
      available_from: p.available_from ? String(p.available_from).slice(0, 10) : '',
    })).catch((e) => setError(e.message));
  }, []);

  if (!f) return error ? <Alert>{error}</Alert> : <Spinner />;
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const upd = (key, i, patch) => setF({ ...f, [key]: f[key].map((x, j) => (j === i ? { ...x, ...patch } : x)) });

  const save = async (e) => {
    e.preventDefault();
    setError(''); setOk(''); setBusy(true);
    try {
      await api.put('/technician/profile', { ...f, portfolio: f.portfolio.split('\n') });
      setOk('Profile saved.');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };

  return (
    <form onSubmit={save} className="mx-auto max-w-3xl space-y-6">
      <h1 className="text-2xl font-bold text-navy-900">My profile</h1>
      <Alert>{error}</Alert>
      <Alert kind="success">{ok}</Alert>
      <section className="card space-y-4">
        <div><label className="label" htmlFor="hl">Professional headline</label><input id="hl" className="input" value={f.headline || ''} onChange={set('headline')} placeholder="e.g. Full-stack engineer (Node + React)" /></div>
        <div><label className="label" htmlFor="bio">About you</label><textarea id="bio" rows={3} className="input" value={f.bio || ''} onChange={set('bio')} /></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="label" htmlFor="ey">Total years of experience</label><input id="ey" type="number" min="0" step="0.5" className="input" value={f.experience_years ?? ''} onChange={set('experience_years')} /></div>
          <div><label className="label" htmlFor="cp">Completed projects</label><input id="cp" type="number" min="0" className="input" value={f.completed_projects ?? 0} onChange={set('completed_projects')} /></div>
        </div>
      </section>

      <section className="card space-y-3">
        <h2 className="font-semibold text-navy-900">Skills</h2>
        <datalist id="sk">{(meta.data?.skills || []).map((s) => <option key={s} value={s} />)}</datalist>
        {f.skills.map((s, i) => (
          <div key={i} className="flex flex-wrap items-center gap-2">
            <input aria-label="Skill" list="sk" className="input w-48" placeholder="Skill" value={s.name} onChange={(e) => upd('skills', i, { name: e.target.value })} />
            <select aria-label="Proficiency" className="input w-44" value={s.level} onChange={(e) => upd('skills', i, { level: Number(e.target.value) })}>
              {[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>Level {n} of 5</option>)}
            </select>
            <input aria-label="Years with this skill" type="number" min="0" step="0.5" className="input w-36" placeholder="Years" value={s.years ?? ''} onChange={(e) => upd('skills', i, { years: e.target.value })} />
            <button type="button" className="btn btn-outline" onClick={() => setF({ ...f, skills: f.skills.filter((_, j) => j !== i) })}>Remove</button>
          </div>
        ))}
        <button type="button" className="btn btn-outline" onClick={() => setF({ ...f, skills: [...f.skills, { name: '', level: 3, years: '' }] })}>Add a skill</button>

        <h3 className="pt-2 text-sm font-semibold text-slate-700">Certifications (self-reported until an administrator verifies them)</h3>
        {f.certifications.map((c, i) => (
          <div key={i} className="flex flex-wrap items-center gap-2">
            <input aria-label="Certification" className="input w-72" value={c.name} onChange={(e) => upd('certifications', i, { name: e.target.value })} />
            <span className="text-xs text-slate-500">{c.verified ? 'Verified' : 'Not verified'}</span>
            <button type="button" className="btn btn-outline" onClick={() => setF({ ...f, certifications: f.certifications.filter((_, j) => j !== i) })}>Remove</button>
          </div>
        ))}
        <button type="button" className="btn btn-outline" onClick={() => setF({ ...f, certifications: [...f.certifications, { name: '', verified: false }] })}>Add a certification</button>
        <div><label className="label" htmlFor="pf">Portfolio links (one per line)</label><textarea id="pf" rows={3} className="input" value={f.portfolio} onChange={set('portfolio')} /></div>
      </section>

      <section className="card grid gap-4 sm:grid-cols-2">
        <div><label className="label" htmlFor="city">Your city</label>
          <select id="city" className="input" value={f.city || ''} onChange={set('city')}><option value="">Select a city</option>{(meta.data?.cities || []).map((c) => <option key={c}>{c}</option>)}</select></div>
        <div><label className="label" htmlFor="tr">Travel radius (km)</label><input id="tr" type="number" min="0" className="input" value={f.travel_radius_km ?? ''} onChange={set('travel_radius_km')} /></div>
        <div><label className="label" htmlFor="af">Available from</label><input id="af" type="date" className="input" value={f.available_from} onChange={set('available_from')} /></div>
        <div><label className="label" htmlFor="ed">Typical time to finish a job (days)</label><input id="ed" type="number" min="1" className="input" value={f.est_days ?? ''} onChange={set('est_days')} /></div>
        <div><label className="label" htmlFor="pm">Pricing</label>
          <select id="pm" className="input" value={f.pricing_model} onChange={set('pricing_model')}><option value="hourly">Hourly rate</option><option value="fixed">Fixed job price</option></select></div>
        {f.pricing_model === 'fixed'
          ? <div><label className="label" htmlFor="fp">Fixed price for a typical job (₹)</label><input id="fp" type="number" min="0" className="input" value={f.fixed_price ?? ''} onChange={set('fixed_price')} /></div>
          : <div><label className="label" htmlFor="hr">Hourly rate (₹)</label><input id="hr" type="number" min="0" className="input" value={f.hourly_rate ?? ''} onChange={set('hourly_rate')} /></div>}
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.remote_ok !== false} onChange={set('remote_ok')} /> I can work remotely</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.willing !== false} onChange={set('willing')} /> I am currently accepting new jobs</label>
      </section>
      <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving...' : 'Save profile'}</button>
    </form>
  );
}

import { useEffect, useState } from 'react';

export const inr = (n) => (n === null || n === undefined ? 'Unknown' : '₹' + Math.round(Number(n)).toLocaleString('en-IN'));

export function Alert({ kind = 'error', children }) {
  if (!children) return null;
  const c = kind === 'error' ? 'border-red-200 bg-red-50 text-red-800' : kind === 'success' ? 'border-teal-200 bg-teal-50 text-teal-800' : 'border-amber-200 bg-amber-50 text-amber-800';
  return <div role="alert" className={`rounded-lg border px-4 py-3 text-sm ${c}`}>{children}</div>;
}

export function Spinner({ label = 'Loading...' }) {
  return <p className="py-10 text-center text-sm text-slate-500">{label}</p>;
}

export function Empty({ title, children }) {
  return (
    <div className="rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center">
      <p className="font-semibold text-slate-700">{title}</p>
      <div className="mt-2 text-sm text-slate-500">{children}</div>
    </div>
  );
}

export function Stat({ label, value, tone = 'indigo' }) {
  const t = { indigo: 'text-indigo-700', teal: 'text-teal-700', navy: 'text-navy-900', amber: 'text-amber-600' }[tone];
  return (
    <div className="card">
      <p className={`text-3xl font-bold ${t}`}>{value ?? 0}</p>
      <p className="mt-1 text-sm text-slate-500">{label}</p>
    </div>
  );
}

const BADGE = {
  'Highly Recommended': 'bg-teal-100 text-teal-800',
  'Moderately Recommended': 'bg-indigo-100 text-indigo-800',
  'Low Priority': 'bg-slate-200 text-slate-700',
  pending: 'bg-amber-100 text-amber-800',
  accepted: 'bg-teal-100 text-teal-800',
  declined: 'bg-red-100 text-red-800',
  clarification: 'bg-indigo-100 text-indigo-800',
  withdrawn: 'bg-slate-200 text-slate-600',
  expired: 'bg-slate-200 text-slate-600',
  open: 'bg-teal-100 text-teal-800',
  filled: 'bg-indigo-100 text-indigo-800',
  closed: 'bg-slate-200 text-slate-600',
};
export function Badge({ children, tone }) {
  return <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold ${BADGE[tone || children] || 'bg-slate-100 text-slate-700'}`}>{children}</span>;
}

export function Bar({ label, value, detail }) {
  const unknown = value === null || value === undefined;
  const color = unknown ? 'bg-slate-300' : value >= 80 ? 'bg-teal-600' : value >= 60 ? 'bg-indigo-500' : value >= 40 ? 'bg-amber-500' : 'bg-red-500';
  return (
    <div title={detail}>
      <div className="flex justify-between text-xs text-slate-600">
        <span>{label}</span>
        <span>{unknown ? 'unknown / n/a' : Math.round(value)}</span>
      </div>
      <div className="mt-1 h-2 rounded-full bg-slate-100">
        <div className={`h-2 rounded-full ${color}`} style={{ width: `${unknown ? 0 : value}%` }} />
      </div>
    </div>
  );
}

export function useLoad(fn, deps = []) {
  const [state, set] = useState({ data: null, error: '', loading: true });
  const reload = () => {
    set((s) => ({ ...s, loading: true }));
    return fn().then((data) => set({ data, error: '', loading: false })).catch((e) => set({ data: null, error: e.message, loading: false }));
  };
  useEffect(() => { reload(); /* eslint-disable-next-line */ }, deps);
  return { ...state, reload };
}

export const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : 'Not set');

import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { Bell, LogOut, Wrench } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useAuth, homeFor } from '../auth';
import { api } from '../api';

export default function Layout() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!user) return;
    api.get('/notifications').then((n) => setUnread(n.filter((x) => !x.read).length)).catch(() => {});
  }, [user]);

  const links = !user ? [] : user.role === 'hiring'
    ? [['/dashboard', 'Dashboard'], ['/jobs/new', 'Post a job']]
    : user.role === 'technician'
    ? [['/tech', 'Dashboard'], ['/profile', 'My profile']]
    : [['/admin', 'Admin']];
  const cls = ({ isActive }) => `rounded-md px-3 py-1.5 text-sm font-medium ${isActive ? 'bg-white/15 text-white' : 'text-slate-200 hover:text-white'}`;

  return (
    <div className="min-h-screen">
      <header className="bg-navy-900">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-2 px-4 py-3">
          <Link to={user ? homeFor(user) : '/'} className="mr-4 flex items-center gap-2 text-lg font-bold text-white">
            <Wrench size={20} className="text-teal-100" /> TechMatch
          </Link>
          <nav className="flex flex-1 flex-wrap gap-1">{links.map(([to, t]) => <NavLink key={to} to={to} className={cls}>{t}</NavLink>)}</nav>
          {user ? (
            <div className="flex items-center gap-3 text-sm text-slate-200">
              <Link to="/notifications" className="relative rounded-md p-1.5 hover:text-white" aria-label="Notifications">
                <Bell size={18} />
                {unread > 0 && <span className="absolute -right-1 -top-1 rounded-full bg-teal-600 px-1.5 text-[10px] font-bold text-white">{unread}</span>}
              </Link>
              <span className="hidden sm:inline">{user.name}</span>
              <button className="flex items-center gap-1 rounded-md px-2 py-1 hover:text-white" onClick={() => { logout(); nav('/'); }}>
                <LogOut size={16} /> Log out
              </button>
            </div>
          ) : (
            <div className="flex gap-2">
              <Link to="/login" className="btn btn-outline">Log in</Link>
              <Link to="/register" className="btn btn-teal">Create account</Link>
            </div>
          )}
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8"><Outlet /></main>
    </div>
  );
}

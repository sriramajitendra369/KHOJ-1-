import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { pool, initDb, CITIES, SKILLS } from './db.js';
import { matchTechnicians, DEFAULT_SETTINGS, CRITERIA } from './matching-engine.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret';
if (!process.env.JWT_SECRET) console.warn('WARNING: JWT_SECRET not set; using an insecure development secret.');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const q = (text, params) => pool.query(text, params).then((r) => r.rows);
const h = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const num = (v) => (v === null || v === undefined || v === '' || Number.isNaN(Number(v)) ? null : Number(v));
const J = (v) => JSON.stringify(v ?? []);

// ---------- auth ----------
const sign = (u) => jwt.sign({ id: u.id, role: u.role }, JWT_SECRET, { expiresIn: '7d' });
const auth = (roles) => (req, res, next) => {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  try {
    req.user = jwt.verify(t, JWT_SECRET);
  } catch {
    return bad(res, 'Please log in again', 401);
  }
  if (roles && !roles.includes(req.user.role)) return bad(res, 'You do not have access to this', 403);
  next();
};
const notify = (userId, title, body) => q('INSERT INTO notifications (user_id,title,body) VALUES ($1,$2,$3)', [userId, title, body]);
const audit = (actor, action, detail) => q('INSERT INTO audit_logs (actor_id,action,detail) VALUES ($1,$2,$3)', [actor, action, JSON.stringify(detail || {})]);

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.get('/api/meta', (req, res) => res.json({ cities: Object.keys(CITIES), skills: SKILLS, criteria: CRITERIA }));

app.post('/api/auth/register', h(async (req, res) => {
  const { email, password, name, role } = req.body || {};
  if (!email || !/^\S+@\S+\.\S+$/.test(email)) return bad(res, 'Enter a valid email address');
  if (!password || password.length < 6) return bad(res, 'Password must be at least 6 characters');
  if (!name || !name.trim()) return bad(res, 'Enter your name');
  if (!['hiring', 'technician'].includes(role)) return bad(res, 'Choose hiring manager or technician');
  const exists = await q('SELECT 1 FROM users WHERE email=$1', [email.toLowerCase()]);
  if (exists.length) return bad(res, 'An account with this email already exists', 409);
  const [u] = await q('INSERT INTO users (email,password_hash,name,role) VALUES ($1,$2,$3,$4) RETURNING id,email,name,role', [email.toLowerCase(), await bcrypt.hash(password, 10), name.trim(), role]);
  if (role === 'technician') await q('INSERT INTO technician_profiles (user_id) VALUES ($1)', [u.id]);
  res.json({ token: sign(u), user: u });
}));

app.post('/api/auth/login', h(async (req, res) => {
  const { email, password } = req.body || {};
  const [u] = await q('SELECT * FROM users WHERE email=$1', [String(email || '').toLowerCase()]);
  if (!u || !(await bcrypt.compare(password || '', u.password_hash))) return bad(res, 'Email or password is incorrect', 401);
  res.json({ token: sign(u), user: { id: u.id, email: u.email, name: u.name, role: u.role } });
}));

// ---------- jobs ----------
const LEVELS = ['remote', 'onsite', 'hybrid'];
function cleanJob(b) {
  const skills = (Array.isArray(b.required_skills) ? b.required_skills : [])
    .filter((s) => s && String(s.name || '').trim())
    .map((s) => ({ name: String(s.name).trim(), min_level: Math.min(5, Math.max(1, num(s.min_level) || 1)), mandatory: s.mandatory !== false }));
  const certs = (Array.isArray(b.certifications) ? b.certifications : [])
    .filter((c) => c && String(c.name || '').trim())
    .map((c) => ({ name: String(c.name).trim(), mandatory: !!c.mandatory }));
  return { skills, certs };
}
function validateJob(b, skills) {
  if (!b.title || !String(b.title).trim()) return 'Enter a job title';
  if (!skills.length) return 'Add at least one required skill';
  if (!LEVELS.includes(b.work_type)) return 'Choose remote, on-site or hybrid';
  if (b.work_type !== 'remote' && !CITIES[b.city]) return 'Choose the job location';
  const dur = num(b.duration_hours);
  if (!dur || dur <= 0) return 'Enter the estimated duration in hours';
  const min = num(b.budget_min);
  const max = num(b.budget_max);
  if (min !== null && max !== null && min > max) return 'Minimum budget cannot be higher than maximum budget';
  if (b.budget_hard && max === null) return 'A hard budget limit needs a maximum budget';
  return null;
}

app.post('/api/jobs', auth(['hiring', 'admin']), h(async (req, res) => {
  const b = req.body || {};
  const { skills, certs } = cleanJob(b);
  const err = validateJob(b, skills);
  if (err) return bad(res, err);
  const [lat, lng] = CITIES[b.city] || [null, null];
  const [job] = await q(
    `INSERT INTO jobs (owner_id,title,description,category,required_skills,certifications,min_experience,work_type,city,lat,lng,max_distance_km,deadline,duration_hours,budget_min,budget_max,budget_hard,payment_model,conditions)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19) RETURNING *`,
    [req.user.id, b.title.trim(), b.description || null, b.category || null, J(skills), J(certs), num(b.min_experience), b.work_type, b.city || null, lat, lng, num(b.max_distance_km), b.deadline || null, num(b.duration_hours), num(b.budget_min), num(b.budget_max), !!b.budget_hard, b.payment_model || 'hourly', b.conditions || null]
  );
  res.json(job);
}));

app.get('/api/jobs', auth(['hiring', 'admin']), h(async (req, res) => {
  const where = req.user.role === 'admin' ? '' : 'WHERE j.owner_id=$1';
  const rows = await q(
    `SELECT j.*, (SELECT COUNT(*)::int FROM invitations i WHERE i.job_id=j.id) AS invitation_count,
            (SELECT COUNT(*)::int FROM shortlists s WHERE s.job_id=j.id) AS shortlist_count
     FROM jobs j ${where} ORDER BY j.created_at DESC`, req.user.role === 'admin' ? [] : [req.user.id]);
  res.json(rows);
}));

async function getOwnedJob(req, res) {
  const [job] = await q('SELECT * FROM jobs WHERE id=$1', [req.params.id]);
  if (!job) { bad(res, 'Job not found', 404); return null; }
  if (req.user.role !== 'admin' && job.owner_id !== req.user.id) { bad(res, 'You do not have access to this job', 403); return null; }
  return job;
}

app.get('/api/jobs/:id', auth(['hiring', 'admin']), h(async (req, res) => {
  const job = await getOwnedJob(req, res);
  if (job) res.json(job);
}));

app.put('/api/jobs/:id/status', auth(['hiring', 'admin']), h(async (req, res) => {
  const job = await getOwnedJob(req, res);
  if (!job) return;
  if (!['open', 'filled', 'closed'].includes(req.body.status)) return bad(res, 'Invalid status');
  await q('UPDATE jobs SET status=$1 WHERE id=$2', [req.body.status, job.id]);
  res.json({ ok: true });
}));

async function getSettings() {
  const [row] = await q("SELECT value FROM settings WHERE key='matching'");
  const v = row?.value || {};
  return { weights: { ...DEFAULT_SETTINGS.weights, ...(v.weights || {}) }, thresholds: { ...DEFAULT_SETTINGS.thresholds, ...(v.thresholds || {}) } };
}

async function loadTechnicians() {
  return q(
    `SELECT u.id AS technician_id, u.name, p.*, r.rating_avg, COALESCE(r.review_count,0) AS review_count
     FROM users u JOIN technician_profiles p ON p.user_id=u.id
     LEFT JOIN (SELECT technician_id, AVG(rating)::float AS rating_avg, COUNT(*)::int AS review_count FROM reviews GROUP BY technician_id) r ON r.technician_id=u.id
     WHERE u.role='technician'`);
}

app.get('/api/jobs/:id/matches', auth(['hiring', 'admin']), h(async (req, res) => {
  const job = await getOwnedJob(req, res);
  if (!job) return;
  const settings = await getSettings();
  let used = settings;
  if (req.query.weights) {
    try {
      const w = JSON.parse(req.query.weights);
      used = { ...settings, weights: Object.fromEntries(CRITERIA.map((k) => [k, Math.max(0, num(w[k]) ?? 0)])) };
    } catch { return bad(res, 'Invalid weights'); }
  }
  const { eligible, nearMatches } = matchTechnicians(job, await loadTechnicians(), used);
  const shortlist = (await q('SELECT technician_id FROM shortlists WHERE job_id=$1', [job.id])).map((r) => r.technician_id);
  const invited = await q('SELECT technician_id, status FROM invitations WHERE job_id=$1', [job.id]);
  res.json({ job, eligible, nearMatches, shortlist, invited, settings: used, defaults: settings });
}));

app.post('/api/jobs/:id/shortlist', auth(['hiring', 'admin']), h(async (req, res) => {
  const job = await getOwnedJob(req, res);
  if (!job) return;
  const tid = num(req.body.technician_id);
  if (!tid) return bad(res, 'technician_id required');
  const del = await pool.query('DELETE FROM shortlists WHERE job_id=$1 AND technician_id=$2', [job.id, tid]);
  if (del.rowCount === 0) await q('INSERT INTO shortlists (job_id,technician_id) VALUES ($1,$2)', [job.id, tid]);
  res.json({ shortlisted: del.rowCount === 0 });
}));

// ---------- technician profile ----------
app.get('/api/technician/profile', auth(['technician']), h(async (req, res) => {
  const [p] = await q('SELECT * FROM technician_profiles WHERE user_id=$1', [req.user.id]);
  const [u] = await q('SELECT name,email FROM users WHERE id=$1', [req.user.id]);
  res.json({ ...p, name: u.name, email: u.email });
}));

app.put('/api/technician/profile', auth(['technician']), h(async (req, res) => {
  const b = req.body || {};
  const skills = (Array.isArray(b.skills) ? b.skills : []).filter((s) => s && String(s.name || '').trim())
    .map((s) => ({ name: String(s.name).trim(), level: Math.min(5, Math.max(1, num(s.level) || 1)), years: num(s.years) }));
  const certs = (Array.isArray(b.certifications) ? b.certifications : []).filter((c) => c && String(c.name || '').trim())
    .map((c) => ({ name: String(c.name).trim(), verified: false })); // self-reported until an admin verifies
  const portfolio = (Array.isArray(b.portfolio) ? b.portfolio : []).filter((x) => x && String(x).trim()).map(String);
  if (b.city && !CITIES[b.city]) return bad(res, 'Choose a city from the list');
  const [lat, lng] = CITIES[b.city] || [null, null];
  // Preserve verified flag for certifications that already exist
  const [old] = await q('SELECT certifications FROM technician_profiles WHERE user_id=$1', [req.user.id]);
  const oldCerts = old?.certifications || [];
  for (const c of certs) { const o = oldCerts.find((x) => x.name.toLowerCase() === c.name.toLowerCase()); if (o?.verified) c.verified = true; }
  await q(
    `UPDATE technician_profiles SET headline=$1,bio=$2,skills=$3,experience_years=$4,certifications=$5,portfolio=$6,city=$7,lat=$8,lng=$9,
       travel_radius_km=$10,remote_ok=$11,available_from=$12,hourly_rate=$13,fixed_price=$14,pricing_model=$15,est_days=$16,willing=$17,completed_projects=$18,updated_at=now()
     WHERE user_id=$19`,
    [b.headline || null, b.bio || null, J(skills), num(b.experience_years), J(certs), J(portfolio), b.city || null, lat, lng, num(b.travel_radius_km), b.remote_ok !== false, b.available_from || null, num(b.hourly_rate), num(b.fixed_price), b.pricing_model === 'fixed' ? 'fixed' : 'hourly', num(b.est_days), b.willing !== false, num(b.completed_projects) ?? 0, req.user.id]
  );
  res.json({ ok: true });
}));

// ---------- invitations ----------
app.post('/api/invitations', auth(['hiring']), h(async (req, res) => {
  const { job_id, technician_id, message } = req.body || {};
  const [job] = await q('SELECT * FROM jobs WHERE id=$1 AND owner_id=$2', [job_id, req.user.id]);
  if (!job) return bad(res, 'Job not found', 404);
  const [tech] = await q("SELECT id,name FROM users WHERE id=$1 AND role='technician'", [technician_id]);
  if (!tech) return bad(res, 'Technician not found', 404);
  const dup = await q('SELECT status FROM invitations WHERE job_id=$1 AND technician_id=$2', [job_id, technician_id]);
  if (dup.length && dup[0].status !== 'withdrawn') return bad(res, `This technician already has an invitation (${dup[0].status})`, 409);
  if (dup.length) await q('DELETE FROM invitations WHERE job_id=$1 AND technician_id=$2', [job_id, technician_id]);
  const [inv] = await q('INSERT INTO invitations (job_id,technician_id,message) VALUES ($1,$2,$3) RETURNING *', [job_id, technician_id, message || null]);
  const [me] = await q('SELECT name FROM users WHERE id=$1', [req.user.id]);
  await notify(tech.id, `New job invitation: ${job.title}`, `${me.name} invited you to this job. Open your dashboard to accept, decline or ask a question.`);
  res.json(inv);
}));

app.get('/api/invitations', auth(['hiring', 'technician']), h(async (req, res) => {
  if (req.user.role === 'technician') {
    return res.json(await q(
      `SELECT i.*, j.title, j.description, j.city AS job_city, j.work_type, j.deadline, j.budget_min, j.budget_max, j.duration_hours, u.name AS owner_name
       FROM invitations i JOIN jobs j ON j.id=i.job_id JOIN users u ON u.id=j.owner_id
       WHERE i.technician_id=$1 ORDER BY i.created_at DESC`, [req.user.id]));
  }
  res.json(await q(
    `SELECT i.*, j.title, u.name AS technician_name,
            CASE WHEN i.status='accepted' THEN u.email END AS technician_email,
            (SELECT COUNT(*)::int FROM reviews r WHERE r.job_id=i.job_id AND r.technician_id=i.technician_id AND r.reviewer_id=$1) AS reviewed
     FROM invitations i JOIN jobs j ON j.id=i.job_id JOIN users u ON u.id=i.technician_id
     WHERE j.owner_id=$1 ORDER BY i.created_at DESC`, [req.user.id]));
}));

app.post('/api/invitations/:id/respond', auth(['technician']), h(async (req, res) => {
  const { status, note } = req.body || {};
  if (!['accepted', 'declined', 'clarification'].includes(status)) return bad(res, 'Invalid response');
  const [inv] = await q('SELECT i.*, j.owner_id, j.title FROM invitations i JOIN jobs j ON j.id=i.job_id WHERE i.id=$1 AND i.technician_id=$2', [req.params.id, req.user.id]);
  if (!inv) return bad(res, 'Invitation not found', 404);
  if (inv.status === 'withdrawn') return bad(res, 'This invitation was withdrawn');
  await q('UPDATE invitations SET status=$1,response_note=$2,responded_at=now() WHERE id=$3', [status, note || null, inv.id]);
  const [me] = await q('SELECT name FROM users WHERE id=$1', [req.user.id]);
  const verb = { accepted: 'accepted', declined: 'declined', clarification: 'asked a question about' }[status];
  await notify(inv.owner_id, `${me.name} ${verb} your invitation`, `${inv.title}${note ? ': ' + note : ''}`);
  res.json({ ok: true });
}));

app.post('/api/invitations/:id/withdraw', auth(['hiring']), h(async (req, res) => {
  const r = await pool.query(`UPDATE invitations SET status='withdrawn' WHERE id=$1 AND job_id IN (SELECT id FROM jobs WHERE owner_id=$2) AND status IN ('pending','clarification')`, [req.params.id, req.user.id]);
  if (!r.rowCount) return bad(res, 'Only pending invitations can be withdrawn', 404);
  res.json({ ok: true });
}));

// ---------- reviews (only after an accepted invitation, so feedback is genuine) ----------
app.post('/api/reviews', auth(['hiring']), h(async (req, res) => {
  const { job_id, technician_id, rating, comment } = req.body || {};
  const r = num(rating);
  if (!r || r < 1 || r > 5) return bad(res, 'Choose a rating from 1 to 5');
  const ok = await q(`SELECT 1 FROM invitations i JOIN jobs j ON j.id=i.job_id WHERE i.job_id=$1 AND i.technician_id=$2 AND i.status='accepted' AND j.owner_id=$3`, [job_id, technician_id, req.user.id]);
  if (!ok.length) return bad(res, 'You can only review a technician who accepted your job', 403);
  const dup = await q('SELECT 1 FROM reviews WHERE job_id=$1 AND technician_id=$2 AND reviewer_id=$3', [job_id, technician_id, req.user.id]);
  if (dup.length) return bad(res, 'You already reviewed this technician for this job', 409);
  await q('INSERT INTO reviews (job_id,technician_id,reviewer_id,rating,comment) VALUES ($1,$2,$3,$4,$5)', [job_id, technician_id, req.user.id, Math.round(r), comment || null]);
  await notify(technician_id, 'You received a new review', `${Math.round(r)}/5`);
  res.json({ ok: true });
}));

// ---------- notifications ----------
app.get('/api/notifications', auth(), h(async (req, res) => res.json(await q('SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100', [req.user.id]))));
app.post('/api/notifications/read-all', auth(), h(async (req, res) => { await q('UPDATE notifications SET read=true WHERE user_id=$1', [req.user.id]); res.json({ ok: true }); }));

// ---------- dashboards ----------
app.get('/api/dashboard', auth(), h(async (req, res) => {
  if (req.user.role === 'hiring') {
    const [s] = await q(
      `SELECT (SELECT COUNT(*)::int FROM jobs WHERE owner_id=$1) AS jobs,
              (SELECT COUNT(*)::int FROM jobs WHERE owner_id=$1 AND status='open') AS open_jobs,
              (SELECT COUNT(*)::int FROM shortlists s JOIN jobs j ON j.id=s.job_id WHERE j.owner_id=$1) AS shortlisted,
              (SELECT COUNT(*)::int FROM invitations i JOIN jobs j ON j.id=i.job_id WHERE j.owner_id=$1 AND i.status='pending') AS pending,
              (SELECT COUNT(*)::int FROM invitations i JOIN jobs j ON j.id=i.job_id WHERE j.owner_id=$1 AND i.status='accepted') AS accepted,
              (SELECT COUNT(*)::int FROM invitations i JOIN jobs j ON j.id=i.job_id WHERE j.owner_id=$1 AND i.status='declined') AS declined`, [req.user.id]);
    return res.json(s);
  }
  if (req.user.role === 'technician') {
    const [p] = await q('SELECT * FROM technician_profiles WHERE user_id=$1', [req.user.id]);
    const checks = [p.headline, p.bio, (p.skills || []).length, p.experience_years !== null, p.city, p.hourly_rate !== null || p.fixed_price !== null, p.available_from, p.est_days];
    const completion = Math.round((checks.filter(Boolean).length / checks.length) * 100);
    const [s] = await q(
      `SELECT COUNT(*) FILTER (WHERE status='pending')::int AS pending, COUNT(*) FILTER (WHERE status='accepted')::int AS accepted, COUNT(*) FILTER (WHERE status='declined')::int AS declined
       FROM invitations WHERE technician_id=$1`, [req.user.id]);
    const [r] = await q('SELECT AVG(rating)::float AS rating, COUNT(*)::int AS reviews FROM reviews WHERE technician_id=$1', [req.user.id]);
    return res.json({ ...s, completion, rating: r.rating, reviews: r.reviews, verified: p.verified });
  }
  res.json({});
}));

// ---------- admin ----------
app.get('/api/admin/stats', auth(['admin']), h(async (req, res) => {
  const [s] = await q(`SELECT (SELECT COUNT(*)::int FROM users) AS users, (SELECT COUNT(*)::int FROM users WHERE role='technician') AS technicians,
    (SELECT COUNT(*)::int FROM users WHERE role='hiring') AS employers, (SELECT COUNT(*)::int FROM jobs) AS jobs,
    (SELECT COUNT(*)::int FROM invitations) AS invitations, (SELECT COUNT(*)::int FROM invitations WHERE status='accepted') AS accepted`);
  const technicians = await q(`SELECT u.id,u.name,u.email,p.headline,p.city,p.verified,p.certifications FROM users u JOIN technician_profiles p ON p.user_id=u.id ORDER BY u.created_at`);
  const logs = await q('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 15');
  res.json({ stats: s, technicians, logs, settings: await getSettings() });
}));
app.put('/api/admin/settings', auth(['admin']), h(async (req, res) => {
  const { weights, thresholds } = req.body || {};
  const w = Object.fromEntries(CRITERIA.map((k) => [k, Math.max(0, num(weights?.[k]) ?? 0)]));
  if (CRITERIA.reduce((s, k) => s + w[k], 0) <= 0) return bad(res, 'At least one weight must be above zero');
  const t = { high: num(thresholds?.high) ?? 80, moderate: num(thresholds?.moderate) ?? 60 };
  if (t.moderate >= t.high) return bad(res, 'Moderate threshold must be lower than the high threshold');
  await q(`INSERT INTO settings (key,value) VALUES ('matching',$1) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value`, [JSON.stringify({ weights: w, thresholds: t })]);
  await audit(req.user.id, 'update_matching_settings', { weights: w, thresholds: t });
  res.json({ ok: true });
}));
app.post('/api/admin/verify/:userId', auth(['admin']), h(async (req, res) => {
  const verified = !!req.body.verified;
  // Verifying an account also marks its listed certifications as verified
  await q(`UPDATE technician_profiles SET verified=$1, certifications=COALESCE((SELECT jsonb_agg(jsonb_set(c,'{verified}',to_jsonb($1::boolean))) FROM jsonb_array_elements(certifications) c),'[]'::jsonb) WHERE user_id=$2`, [verified, req.params.userId]);
  await audit(req.user.id, verified ? 'verify_technician' : 'unverify_technician', { user_id: Number(req.params.userId) });
  res.json({ ok: true });
}));

// ---------- serve built frontend (single-service deploy) ----------
const dist = path.join(__dirname, '../../frontend/dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (req, res, next) => (req.path.startsWith('/api') ? next() : res.sendFile(path.join(dist, 'index.html'))));
} else {
  app.get('/', (req, res) => res.send('TechMatch API is running. Frontend build not found (run "npm run build" at the repo root).'));
}

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server' });
});

const port = process.env.PORT || 5000;
initDb()
  .then(() => app.listen(port, '0.0.0.0', () => console.log(`TechMatch listening on ${port}`)))
  .catch((e) => {
    console.error('Database initialisation failed:', e.message);
    process.exit(1);
  });

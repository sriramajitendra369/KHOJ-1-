import pg from 'pg';
import bcrypt from 'bcryptjs';

// Return DATE columns as plain 'YYYY-MM-DD' strings (avoids timezone off-by-one-day bugs)
pg.types.setTypeParser(1082, (v) => v);

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('\nDATABASE_URL is not set. Add a Postgres database (Railway Postgres or Supabase) and set DATABASE_URL.\n');
}
const useSsl = process.env.PGSSL === 'true' || /supabase\.(co|com)/.test(url || '');
export const pool = new pg.Pool({ connectionString: url, ssl: useSsl ? { rejectUnauthorized: false } : undefined });

export const CITIES = {
  Hyderabad: [17.385, 78.4867], Warangal: [17.9689, 79.5941], Vijayawada: [16.5062, 80.648],
  Bengaluru: [12.9716, 77.5946], Chennai: [13.0827, 80.2707], Mumbai: [19.076, 72.8777],
  Pune: [18.5204, 73.8567], Delhi: [28.6139, 77.209],
};
export const SKILLS = ['Node.js', 'React', 'PostgreSQL', 'AWS', 'Python', 'Django', 'Java', 'Spring Boot', 'TypeScript', 'Docker',
  'Networking', 'CCTV Installation', 'Electrical Wiring', 'HVAC', 'Laptop Repair', 'Android', 'Flutter', 'UI/UX Design', 'Cybersecurity', 'Data Analysis'];

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('hiring','technician','admin')),
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS technician_profiles (
  user_id INT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  headline TEXT, bio TEXT,
  skills JSONB NOT NULL DEFAULT '[]',
  experience_years NUMERIC,
  certifications JSONB NOT NULL DEFAULT '[]',
  portfolio JSONB NOT NULL DEFAULT '[]',
  city TEXT, lat DOUBLE PRECISION, lng DOUBLE PRECISION,
  travel_radius_km NUMERIC DEFAULT 50,
  remote_ok BOOLEAN DEFAULT true,
  available_from DATE,
  hourly_rate NUMERIC, fixed_price NUMERIC,
  pricing_model TEXT DEFAULT 'hourly' CHECK (pricing_model IN ('hourly','fixed')),
  est_days INT,
  willing BOOLEAN DEFAULT true,
  completed_projects INT DEFAULT 0,
  verified BOOLEAN DEFAULT false,
  updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS jobs (
  id SERIAL PRIMARY KEY,
  owner_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, description TEXT, category TEXT,
  required_skills JSONB NOT NULL DEFAULT '[]',
  certifications JSONB NOT NULL DEFAULT '[]',
  min_experience NUMERIC,
  work_type TEXT NOT NULL DEFAULT 'onsite' CHECK (work_type IN ('remote','onsite','hybrid')),
  city TEXT, lat DOUBLE PRECISION, lng DOUBLE PRECISION,
  max_distance_km NUMERIC,
  deadline DATE, duration_hours NUMERIC,
  budget_min NUMERIC, budget_max NUMERIC,
  budget_hard BOOLEAN DEFAULT false,
  payment_model TEXT DEFAULT 'hourly' CHECK (payment_model IN ('hourly','fixed','negotiable')),
  conditions TEXT,
  status TEXT DEFAULT 'open' CHECK (status IN ('open','filled','closed')),
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS invitations (
  id SERIAL PRIMARY KEY,
  job_id INT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  technician_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','declined','clarification','withdrawn','expired')),
  message TEXT, response_note TEXT,
  created_at TIMESTAMPTZ DEFAULT now(), responded_at TIMESTAMPTZ,
  UNIQUE (job_id, technician_id)
);
CREATE TABLE IF NOT EXISTS shortlists (
  job_id INT REFERENCES jobs(id) ON DELETE CASCADE,
  technician_id INT REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (job_id, technician_id)
);
CREATE TABLE IF NOT EXISTS reviews (
  id SERIAL PRIMARY KEY,
  job_id INT REFERENCES jobs(id) ON DELETE SET NULL,
  technician_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reviewer_id INT REFERENCES users(id) ON DELETE SET NULL,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, body TEXT,
  read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value JSONB NOT NULL);
CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY, actor_id INT, action TEXT NOT NULL, detail JSONB, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_jobs_owner ON jobs(owner_id);
CREATE INDEX IF NOT EXISTS idx_inv_tech ON invitations(technician_id);
CREATE INDEX IF NOT EXISTS idx_reviews_tech ON reviews(technician_id);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id);
`;

const daysFromNow = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
const sk = (...a) => a.map(([name, level, years]) => ({ name, level, years }));

// 10 FICTIONAL technicians, each designed to demonstrate one behaviour of the matching engine
// against the first demo job ("Build REST API and admin dashboard", Hyderabad, hybrid).
const DEMO_TECHS = [
  { name: 'Sarah Khan', email: 'sarah@example.com', headline: 'Full-stack engineer (Node + React)', city: 'Hyderabad', skills: sk(['Node.js', 5, 6], ['React', 4, 5], ['PostgreSQL', 4, 5], ['AWS', 3, 3]), exp: 6, certs: [{ name: 'AWS Certified Developer', verified: true }], rate: 700, avail: 0, days: 12, projects: 24, verified: true, reviews: [5, 5, 4] },
  { name: 'Rahul Verma', email: 'rahul@example.com', headline: 'Senior full-stack lead', city: 'Hyderabad', skills: sk(['Node.js', 5, 9], ['React', 5, 8], ['PostgreSQL', 5, 8], ['AWS', 4, 6]), exp: 9, certs: [{ name: 'AWS Certified Developer', verified: true }], rate: 900, avail: 70, days: 10, projects: 40, verified: true, reviews: [5, 5, 5, 4] }, // highly skilled but unavailable
  { name: 'Anil Reddy', email: 'anil@example.com', headline: 'Frontend developer, budget friendly', city: 'Warangal', skills: sk(['React', 4, 4], ['TypeScript', 3, 2]), exp: 4, certs: [], rate: 300, avail: 0, days: 15, projects: 11, verified: false, reviews: [4, 4] }, // inexpensive, lacks mandatory Node.js
  { name: 'Priya Nair', email: 'priya@example.com', headline: 'Backend + React specialist', city: 'Chennai', skills: sk(['Node.js', 5, 7], ['React', 5, 6], ['PostgreSQL', 4, 5]), exp: 7, certs: [{ name: 'AWS Certified Developer', verified: true }], rate: 800, avail: 0, days: 10, projects: 30, verified: true, reviews: [5, 4, 5], radius: 40, remote: false }, // experienced but outside travel radius
  { name: 'Imran Sheikh', email: 'imran@example.com', headline: 'Node/React developer', city: 'Hyderabad', skills: sk(['Node.js', 4, 5], ['React', 4, 5], ['PostgreSQL', 3, 3], ['AWS', 3, 3]), exp: 5, certs: [], rate: 750, avail: 0, days: 12, projects: 15, verified: true, reviews: [4, 4, 5] }, // lacks preferred certification
  { name: 'Divya Menon', email: 'divya@example.com', headline: 'Full-stack developer', city: 'Hyderabad', skills: sk(['Node.js', 4, 5], ['React', 4, 5], ['PostgreSQL', 3, 3], ['AWS', 3, 3]), exp: 5, certs: [], rate: 750, avail: 0, days: 12, projects: 15, verified: true, reviews: [4, 4, 5] }, // near-identical to Imran: tie-breaker demo
  { name: 'Karthik Rao', email: 'karthik@example.com', headline: 'Junior web developer', city: 'Hyderabad', skills: sk(['Node.js', 3, 2], ['React', 3, 2]), exp: 3, certs: [], rate: 500, avail: 5, days: 20, projects: 6, verified: false, reviews: [3, 4] },
  { name: 'Meera Joshi', email: 'meera@example.com', headline: 'Remote React/Node contractor', city: 'Pune', skills: sk(['Node.js', 4, 5], ['React', 5, 6], ['UI/UX Design', 3, 3]), exp: 6, certs: [], rate: 650, avail: 0, days: 12, projects: 19, verified: true, reviews: [5, 4, 5], radius: 80 },
  { name: 'Vikram Singh', email: 'vikram@example.com', headline: 'Python/Django backend engineer', city: 'Bengaluru', skills: sk(['Python', 5, 7], ['Django', 5, 6], ['PostgreSQL', 5, 6]), exp: 7, certs: [], rate: 850, avail: 0, days: 10, projects: 22, verified: true, reviews: [5, 5] },
  { name: 'Neha Gupta', email: 'neha@example.com', headline: 'Early-career full-stack developer', city: 'Hyderabad', skills: sk(['Node.js', 3, 2], ['React', 4, 2], ['PostgreSQL', 2, 1]), exp: 2, certs: [], rate: 450, avail: 0, days: 18, projects: 4, verified: false, reviews: [] }, // no reviews yet: missing-data warning
];

async function seed() {
  const { rows } = await pool.query('SELECT COUNT(*)::int AS n FROM users');
  if (rows[0].n > 0) return;
  console.log('Seeding fictional demo data...');
  const hash = await bcrypt.hash('password', 10);
  const admin = (await pool.query(`INSERT INTO users (email,password_hash,name,role) VALUES ('admin@example.com',$1,'Demo Admin','admin') RETURNING id`, [hash])).rows[0];
  const john = (await pool.query(`INSERT INTO users (email,password_hash,name,role) VALUES ('john@example.com',$1,'John Mehta (demo employer)','hiring') RETURNING id`, [hash])).rows[0];
  for (const t of DEMO_TECHS) {
    const u = (await pool.query(`INSERT INTO users (email,password_hash,name,role) VALUES ($1,$2,$3,'technician') RETURNING id`, [t.email, hash, t.name])).rows[0];
    const [lat, lng] = CITIES[t.city];
    await pool.query(
      `INSERT INTO technician_profiles (user_id,headline,bio,skills,experience_years,certifications,city,lat,lng,travel_radius_km,remote_ok,available_from,hourly_rate,pricing_model,est_days,willing,completed_projects,verified)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'hourly',$14,true,$15,$16)`,
      [u.id, t.headline, 'Fictional demonstration profile.', JSON.stringify(t.skills), t.exp, JSON.stringify(t.certs), t.city, lat, lng, t.radius ?? 60, t.remote ?? true, daysFromNow(t.avail), t.rate, t.days, t.projects, t.verified]
    );
    for (const r of t.reviews) await pool.query(`INSERT INTO reviews (technician_id,reviewer_id,rating,comment) VALUES ($1,$2,$3,'Demo review (fictional)')`, [u.id, john.id, r]);
  }
  const [hl, hn] = CITIES.Hyderabad;
  await pool.query(
    `INSERT INTO jobs (owner_id,title,description,category,required_skills,certifications,min_experience,work_type,city,lat,lng,max_distance_km,deadline,duration_hours,budget_min,budget_max,budget_hard,payment_model)
     VALUES ($1,'Build REST API and admin dashboard','Fictional demo job: Node.js API with a React admin dashboard.','Software',$2,$3,4,'hybrid','Hyderabad',$4,$5,50,$6,60,30000,60000,true,'hourly')`,
    [john.id, JSON.stringify([{ name: 'Node.js', min_level: 3, mandatory: true }, { name: 'React', min_level: 3, mandatory: true }, { name: 'PostgreSQL', min_level: 2, mandatory: false }, { name: 'AWS', min_level: 2, mandatory: false }]), JSON.stringify([{ name: 'AWS Certified Developer', mandatory: false }]), hl, hn, daysFromNow(45)]
  );
  await pool.query(
    `INSERT INTO jobs (owner_id,title,description,category,required_skills,certifications,min_experience,work_type,city,lat,lng,deadline,duration_hours,budget_min,budget_max,budget_hard,payment_model)
     VALUES ($1,'Remote React analytics dashboard','Fictional demo job: remote, React-focused.','Software',$2,'[]',3,'remote','Hyderabad',$3,$4,$5,40,15000,45000,false,'fixed')`,
    [john.id, JSON.stringify([{ name: 'React', min_level: 4, mandatory: true }, { name: 'TypeScript', min_level: 2, mandatory: false }]), hl, hn, daysFromNow(30)]
  );
  await pool.query(`INSERT INTO audit_logs (actor_id, action, detail) VALUES ($1,'seed','{"note":"demo data loaded"}')`, [admin.id]);
}

export async function initDb() {
  await pool.query(SCHEMA);
  await pool.query(`INSERT INTO settings (key,value) VALUES ('matching',$1) ON CONFLICT (key) DO NOTHING`, [
    JSON.stringify({ weights: { skills: 30, availability: 20, location: 15, price: 15, experience: 10, certifications: 5, reviews: 5 }, thresholds: { high: 80, moderate: 60 } }),
  ]);
  if (process.env.SEED_DEMO_DATA !== 'false') await seed();
}

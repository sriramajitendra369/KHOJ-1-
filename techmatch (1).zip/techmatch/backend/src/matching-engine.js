// Deterministic, explainable matching engine.
// Step A: mandatory eligibility filters. Step B: weighted score (0-100). Step C: categories,
// explanations, tie-breakers, missing-data handling.

export const DEFAULT_SETTINGS = {
  weights: { skills: 30, availability: 20, location: 15, price: 15, experience: 10, certifications: 5, reviews: 5 },
  thresholds: { high: 80, moderate: 60 },
};

export const CRITERIA = Object.keys(DEFAULT_SETTINGS.weights);
const DAY = 86400000;
const HOURS_PER_WORKDAY = 6;

const num = (v) => (v === null || v === undefined || v === '' || Number.isNaN(Number(v)) ? null : Number(v));
const norm = (s) => String(s || '').trim().toLowerCase();
const clamp = (n, a = 0, b = 100) => Math.max(a, Math.min(b, n));
const round = (n, d = 1) => Math.round(n * 10 ** d) / 10 ** d;
const toDate = (v) => {
  if (!v) return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
};
const startOfDay = (d) => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
const money = (n) => '₹' + Math.round(n).toLocaleString('en-IN');

export function haversineKm(lat1, lon1, lat2, lon2) {
  const v = [lat1, lon1, lat2, lon2].map(num);
  if (v.some((x) => x === null)) return null;
  const [a1, o1, a2, o2] = v;
  const R = 6371;
  const rad = (x) => (x * Math.PI) / 180;
  const dLat = rad(a2 - a1);
  const dLon = rad(o2 - o1);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a1)) * Math.cos(rad(a2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

// Total expected cost for THIS job. Never compares an hourly rate to a fixed price directly.
export function estimateCost(job, tech) {
  const hours = num(job.duration_hours);
  const fixed = num(tech.fixed_price);
  const rate = num(tech.hourly_rate);
  if (tech.pricing_model === 'fixed' && fixed !== null) return { amount: fixed, basis: 'Fixed price quoted by technician' };
  if (rate !== null && hours) return { amount: rate * hours, basis: `${money(rate)}/h x ${hours}h (estimate)` };
  if (fixed !== null) return { amount: fixed, basis: 'Fixed price quoted by technician' };
  return { amount: null, basis: 'Unknown' };
}

function normalizeWeights(w) {
  const merged = { ...DEFAULT_SETTINGS.weights, ...(w || {}) };
  const clean = {};
  for (const k of CRITERIA) clean[k] = Math.max(0, num(merged[k]) ?? 0);
  const sum = CRITERIA.reduce((s, k) => s + clean[k], 0);
  if (sum === 0) return { ...DEFAULT_SETTINGS.weights };
  const out = {};
  for (const k of CRITERIA) out[k] = (clean[k] / sum) * 100;
  return out;
}

export function evaluateTechnician(job, tech, settings = DEFAULT_SETTINGS, opts = {}) {
  // If a partial weights object is given, unspecified criteria keep their defaults only when
  // the caller passes a full object; for partial objects, unspecified criteria become 0.
  const rawWeights = settings.weights || DEFAULT_SETTINGS.weights;
  const full = CRITERIA.every((k) => k in rawWeights);
  const weights = normalizeWeights(full ? rawWeights : Object.fromEntries(CRITERIA.map((k) => [k, rawWeights[k] ?? 0])));
  const thresholds = { ...DEFAULT_SETTINGS.thresholds, ...(settings.thresholds || {}) };
  const today = startOfDay(opts.today ? new Date(opts.today) : new Date());
  const failures = [];
  const criteria = {};
  const unknown = [];

  const setC = (key, score, detail, status) => {
    criteria[key] = { score: score === null ? null : round(score), detail, status: status || (score === null ? 'unknown' : 'scored') };
    if (criteria[key].status === 'unknown') unknown.push(key);
  };

  if (tech.willing === false) failures.push('Technician is not currently accepting jobs');

  // ---- Skills
  const reqSkills = Array.isArray(job.required_skills) ? job.required_skills : [];
  const techSkills = Array.isArray(tech.skills) ? tech.skills : [];
  const matchedSkills = [];
  const missingPreferred = [];
  const missingMandatory = [];
  let wSum = 0;
  let cSum = 0;
  for (const rs of reqSkills) {
    const minLevel = num(rs.min_level) ?? 1;
    const ts = techSkills.find((s) => norm(s.name) === norm(rs.name));
    const w = rs.mandatory === false ? 1 : 2;
    wSum += w;
    if (!ts) {
      if (rs.mandatory === false) missingPreferred.push(rs.name);
      else {
        missingMandatory.push(rs.name);
        failures.push(`Missing mandatory skill: ${rs.name}`);
      }
      continue;
    }
    const level = num(ts.level) ?? 0;
    if (level < minLevel && rs.mandatory !== false) failures.push(`Skill below required level: ${rs.name} (has ${level}, needs ${minLevel})`);
    cSum += w * clamp(level / minLevel, 0, 1);
    matchedSkills.push({ name: rs.name, level, required: minLevel, years: num(ts.years) });
  }
  if (reqSkills.length === 0) setC('skills', null, 'No skills specified on job', 'n/a');
  else setC('skills', (cSum / wSum) * 100, `${matchedSkills.length}/${reqSkills.length} required skills matched`);

  // ---- Cost
  const cost = estimateCost(job, tech);
  const bMin = num(job.budget_min);
  const bMax = num(job.budget_max);
  let budgetDiff = null;
  if (cost.amount !== null && bMax !== null) budgetDiff = bMax - cost.amount;
  if (cost.amount !== null && bMax !== null && job.budget_hard && cost.amount > bMax)
    failures.push(`Over hard budget limit (${money(cost.amount)} vs max ${money(bMax)})`);
  if (cost.amount === null) setC('price', null, 'Technician has no usable price information');
  else if (bMax === null || job.payment_model === 'negotiable') setC('price', null, 'Job has no budget limit to compare against', 'n/a');
  else {
    const lo = bMin ?? 0;
    let s;
    if (cost.amount <= lo) s = 100;
    else if (cost.amount <= bMax) s = 100 - (40 * (cost.amount - lo)) / Math.max(bMax - lo, 1);
    else s = Math.max(0, 60 - (120 * (cost.amount - bMax)) / bMax);
    setC('price', s, `Expected ${money(cost.amount)} (${cost.basis}) vs budget ${bMin !== null ? money(bMin) + '-' : 'up to '}${money(bMax)}`);
  }

  // ---- Availability
  const availFrom = toDate(tech.available_from);
  const deadline = toDate(job.deadline);
  const estDays = num(tech.est_days) ?? (num(job.duration_hours) ? Math.ceil(num(job.duration_hours) / HOURS_PER_WORKDAY) : null);
  if (!availFrom) setC('availability', null, 'Technician has not set an availability date');
  else {
    const start = availFrom > today ? availFrom : today;
    const waitDays = Math.round((start - today) / DAY);
    if (deadline) {
      const finish = new Date(start.getTime() + (estDays ?? 0) * DAY);
      if (finish > deadline) {
        failures.push(
          estDays === null
            ? `Not available before the deadline (free from ${start.toISOString().slice(0, 10)})`
            : `Cannot finish by deadline (free from ${start.toISOString().slice(0, 10)}, needs about ${estDays} days)`
        );
        setC('availability', 0, `Earliest finish ${finish.toISOString().slice(0, 10)} is after the deadline`);
      } else {
        const slack = Math.round((deadline - finish) / DAY);
        const s = 60 + 40 * Math.min(1, slack / Math.max(estDays || 1, 1));
        setC('availability', s, `Free ${waitDays === 0 ? 'now' : 'in ' + waitDays + ' days'}, finishes about ${slack} days before deadline`);
      }
    } else {
      setC('availability', clamp(100 - waitDays * 3, 30, 100), waitDays === 0 ? 'Available now' : `Available in ${waitDays} days`);
    }
  }

  // ---- Location
  let distanceKm = null;
  if (job.work_type === 'remote') setC('location', 100, 'Remote job - distance not applicable');
  else {
    distanceKm = haversineKm(job.lat, job.lng, tech.lat, tech.lng);
    if (distanceKm === null) setC('location', null, 'Location missing for job or technician');
    else {
      const limits = [num(job.max_distance_km), num(tech.travel_radius_km)].filter((x) => x !== null);
      const limit = limits.length ? Math.min(...limits) : null;
      if (limit !== null && distanceKm > limit) {
        failures.push(`Outside travel limit (${Math.round(distanceKm)} km away, limit ${Math.round(limit)} km)`);
        setC('location', 0, `${Math.round(distanceKm)} km away, beyond ${Math.round(limit)} km limit`);
      } else {
        const s = limit !== null ? 100 - 60 * (distanceKm / limit) : clamp(100 - distanceKm / 10, 20, 100);
        setC('location', s, `${Math.round(distanceKm)} km away`);
      }
    }
  }

  // ---- Experience
  const yrs = matchedSkills.map((m) => m.years).filter((y) => y !== null);
  let relevant = yrs.length ? yrs.reduce((a, b) => a + b, 0) / yrs.length : null;
  let expNote = 'average years across matched skills';
  if (relevant === null && num(tech.experience_years) !== null) {
    relevant = num(tech.experience_years);
    expNote = 'total years (relevant years not specified)';
  }
  const target = num(job.min_experience) || 5;
  if (relevant === null) setC('experience', null, 'No experience information');
  else setC('experience', clamp((relevant / target) * 100), `${round(relevant)} years (${expNote}) vs ${target} wanted`);

  // ---- Certifications
  const reqCerts = Array.isArray(job.certifications) ? job.certifications : [];
  const techCerts = Array.isArray(tech.certifications) ? tech.certifications : [];
  const certDrawbacks = [];
  if (reqCerts.length === 0) setC('certifications', null, 'No certifications required', 'n/a');
  else {
    let total = 0;
    let held = 0;
    for (const rc of reqCerts) {
      const tc = techCerts.find((c) => norm(c.name) === norm(rc.name));
      if (!tc) {
        if (rc.mandatory) failures.push(`Missing mandatory certification: ${rc.name}`);
        else certDrawbacks.push(`Lacks preferred certification: ${rc.name}`);
      } else {
        held += 1;
        if (tc.verified) total += 1;
        else {
          total += 0.5;
          certDrawbacks.push(`${rc.name} is self-reported, not verified`);
        }
      }
    }
    setC('certifications', (total / reqCerts.length) * 100, `${held}/${reqCerts.length} required certifications held`);
  }

  // ---- Reviews (Bayesian-smoothed so one 5-star review is not conclusive)
  const rc = num(tech.review_count) ?? 0;
  const ra = num(tech.rating_avg);
  if (rc === 0 || ra === null) setC('reviews', null, 'No reviews yet');
  else {
    const smoothed = (ra * rc + 3.5 * 3) / (rc + 3);
    setC('reviews', (smoothed / 5) * 100, `${round(ra, 2)}/5 from ${rc} review${rc === 1 ? '' : 's'}`);
  }

  // ---- Weighted score over criteria that have data (weights re-normalised, shown transparently)
  const active = CRITERIA.filter((k) => criteria[k].score !== null);
  const wTotal = active.reduce((s, k) => s + weights[k], 0);
  const weightsUsed = {};
  for (const k of CRITERIA) weightsUsed[k] = active.includes(k) && wTotal > 0 ? round((weights[k] / wTotal) * 100) : 0;
  const score = wTotal > 0 ? active.reduce((s, k) => s + criteria[k].score * weights[k], 0) / wTotal : 0;
  const finalScore = round(score, 2);
  const category = finalScore >= thresholds.high ? 'Highly Recommended' : finalScore >= thresholds.moderate ? 'Moderately Recommended' : 'Low Priority';

  const label = { skills: 'Skills', availability: 'Availability', location: 'Location', price: 'Price', experience: 'Experience', certifications: 'Certifications', reviews: 'Reviews' };
  const strengths = [];
  const drawbacks = [...certDrawbacks];
  for (const k of CRITERIA) {
    const s = criteria[k].score;
    if (s === null) continue;
    if (s >= 85) strengths.push(`${label[k]}: ${criteria[k].detail}`);
    else if (s <= 55) drawbacks.push(`${label[k]}: ${criteria[k].detail}`);
  }
  if (missingPreferred.length) drawbacks.push(`Missing preferred skills: ${missingPreferred.join(', ')}`);
  const warnings = unknown.map((k) => `${label[k]} data unknown: ${criteria[k].detail}. Score is based on the remaining criteria.`);
  const confidence = unknown.length === 0 ? 'High' : unknown.length === 1 ? 'Medium' : 'Low';

  return {
    technician_id: tech.technician_id,
    name: tech.name,
    headline: tech.headline,
    city: tech.city,
    verified: !!tech.verified,
    eligible: failures.length === 0,
    failures,
    score: finalScore,
    category,
    criteria,
    weightsUsed,
    matchedSkills,
    missingPreferred,
    missingMandatory,
    distanceKm: distanceKm === null ? null : Math.round(distanceKm),
    estimatedCost: cost,
    budgetDiff,
    relevantYears: relevant === null ? null : round(relevant),
    rating: ra,
    reviewCount: rc,
    completedProjects: num(tech.completed_projects),
    strengths,
    drawbacks,
    warnings,
    confidence,
  };
}

function tieBreak(a, b) {
  return (
    b.score - a.score ||
    (b.criteria.availability.score ?? -1) - (a.criteria.availability.score ?? -1) ||
    (b.criteria.price.score ?? -1) - (a.criteria.price.score ?? -1) ||
    (b.reviewCount || 0) - (a.reviewCount || 0) ||
    a.technician_id - b.technician_id
  );
}

export function matchTechnicians(job, technicians, settings = DEFAULT_SETTINGS, opts = {}) {
  const evaluated = technicians.map((t) => evaluateTechnician(job, t, settings, opts));
  const eligible = evaluated.filter((e) => e.eligible).sort(tieBreak);
  const nearMatches = evaluated.filter((e) => !e.eligible).sort(tieBreak);
  eligible.forEach((e, i) => {
    e.rank = i + 1;
    const ks = Object.keys(e.criteria)
      .filter((k) => e.criteria[k].score !== null)
      .sort((a, b) => e.criteria[b].score - e.criteria[a].score);
    const best = ks[0];
    const worst = ks[ks.length - 1];
    const prev = eligible[i - 1];
    let why = `Ranked #${e.rank} of ${eligible.length} eligible: ${e.score}% overall (${e.category}).`;
    if (best) why += ` Strongest criterion: ${best} (${e.criteria[best].score}).`;
    if (worst && worst !== best) why += ` Weakest: ${worst} (${e.criteria[worst].score}).`;
    if (prev && Math.abs(prev.score - e.score) < 1) why += ' Score is within 1 point of the technician above; order was decided by tie-breakers (availability, then price fit, then review count).';
    e.explanation = why;
  });
  nearMatches.forEach((e) => {
    e.explanation = `Not eligible: ${e.failures.join('; ')}. Shown as a near match because it fails a mandatory requirement. Mark the requirement as flexible to include this technician.`;
  });
  return { eligible, nearMatches };
}

import test from 'node:test';
import assert from 'node:assert/strict';
import { matchTechnicians, evaluateTechnician, haversineKm, DEFAULT_SETTINGS } from '../src/matching-engine.js';

const TODAY = '2026-10-10';
const HYD = { lat: 17.385, lng: 78.4867 };
const job = {
  required_skills: [
    { name: 'Node.js', min_level: 3, mandatory: true },
    { name: 'React', min_level: 3, mandatory: true },
    { name: 'AWS', min_level: 2, mandatory: false },
  ],
  certifications: [{ name: 'AWS Certified', mandatory: false }],
  work_type: 'hybrid', ...HYD, max_distance_km: 50, deadline: '2026-11-10', duration_hours: 60,
  budget_min: 30000, budget_max: 60000, budget_hard: true, payment_model: 'hourly', min_experience: 4,
};
const base = {
  technician_id: 1, name: 'A', ...HYD, travel_radius_km: 60, willing: true, available_from: TODAY, hourly_rate: 600,
  pricing_model: 'hourly', est_days: 10, review_count: 3, rating_avg: 4.8,
  skills: [{ name: 'Node.js', level: 5, years: 5 }, { name: 'React', level: 4, years: 4 }, { name: 'AWS', level: 3, years: 3 }],
  certifications: [{ name: 'AWS Certified', verified: true }],
};
const t = (over) => ({ ...base, ...over });
const run = (techs) => matchTechnicians(job, techs, DEFAULT_SETTINGS, { today: TODAY });

test('haversine Hyderabad-Warangal is about 120-160 km', () => {
  const d = haversineKm(17.385, 78.4867, 17.9689, 79.5941);
  assert.ok(d > 120 && d < 160, String(d));
});

test('strong technician is eligible and Highly Recommended', () => {
  const r = run([t({})]);
  assert.equal(r.eligible.length, 1);
  assert.equal(r.eligible[0].category, 'Highly Recommended');
});

test('missing mandatory skill is excluded even if cheap', () => {
  const r = run([t({ technician_id: 2, hourly_rate: 100, skills: [{ name: 'React', level: 5, years: 5 }] })]);
  assert.equal(r.eligible.length, 0);
  assert.match(r.nearMatches[0].failures[0], /Missing mandatory skill: Node.js/);
});

test('unavailable technician cannot finish by deadline', () => {
  const r = run([t({ technician_id: 3, available_from: '2026-12-15' })]);
  assert.equal(r.eligible.length, 0);
  assert.ok(r.nearMatches[0].failures.some((f) => /deadline/.test(f)));
});

test('outside travel radius is excluded', () => {
  const r = run([t({ technician_id: 4, lat: 13.0827, lng: 80.2707 })]);
  assert.equal(r.eligible.length, 0);
  assert.ok(r.nearMatches[0].failures.some((f) => /travel limit/.test(f)));
});

test('hard budget limit excludes expensive technician', () => {
  assert.equal(run([t({ technician_id: 5, hourly_rate: 2000 })]).eligible.length, 0);
});

test('unwilling technician is excluded', () => {
  assert.equal(run([t({ willing: false })]).eligible.length, 0);
});

test('mandatory requirement cannot be bypassed by high other scores', () => {
  const e = evaluateTechnician(job, t({ skills: [{ name: 'React', level: 5, years: 9 }, { name: 'AWS', level: 5, years: 9 }] }), DEFAULT_SETTINGS, { today: TODAY });
  assert.equal(e.eligible, false);
  assert.ok(e.score > 40);
});

test('no reviews is unknown (not zero) and produces a warning', () => {
  const e = evaluateTechnician(job, t({ review_count: 0, rating_avg: null }), DEFAULT_SETTINGS, { today: TODAY });
  assert.equal(e.criteria.reviews.score, null);
  assert.equal(e.weightsUsed.reviews, 0);
  assert.ok(e.warnings.length > 0);
  assert.equal(e.confidence, 'Medium');
});

test('a single 5-star review is smoothed, not treated as conclusive', () => {
  const one = evaluateTechnician(job, t({ review_count: 1, rating_avg: 5 }), DEFAULT_SETTINGS, { today: TODAY });
  const many = evaluateTechnician(job, t({ review_count: 30, rating_avg: 5 }), DEFAULT_SETTINGS, { today: TODAY });
  assert.ok(one.criteria.reviews.score < many.criteria.reviews.score);
});

test('tie-breaker orders identical scores deterministically', () => {
  const r = run([t({ technician_id: 7 }), t({ technician_id: 6 })]);
  assert.deepEqual(r.eligible.map((e) => e.technician_id), [6, 7]);
  assert.match(r.eligible[1].explanation, /tie-breakers/);
});

test('custom weights are normalised and change ranking', () => {
  const cheap = t({ technician_id: 8, hourly_rate: 300, skills: [{ name: 'Node.js', level: 3, years: 3 }, { name: 'React', level: 3, years: 3 }] });
  const skilled = t({ technician_id: 9, hourly_rate: 800 });
  const priceFirst = matchTechnicians(job, [cheap, skilled], { weights: { skills: 1, price: 99 } }, { today: TODAY });
  assert.equal(priceFirst.eligible[0].technician_id, 8);
  const skillFirst = matchTechnicians(job, [cheap, skilled], { weights: { skills: 99, price: 1 } }, { today: TODAY });
  assert.equal(skillFirst.eligible[0].technician_id, 9);
});

test('remote job ignores distance', () => {
  const r = matchTechnicians({ ...job, work_type: 'remote' }, [t({ lat: 13.0827, lng: 80.2707 })], DEFAULT_SETTINGS, { today: TODAY });
  assert.equal(r.eligible.length, 1);
});

test('flexible (non-mandatory) skill does not exclude', () => {
  const flex = { ...job, required_skills: job.required_skills.map((s) => (s.name === 'React' ? { ...s, mandatory: false } : s)) };
  const r = matchTechnicians(flex, [t({ skills: [{ name: 'Node.js', level: 5, years: 5 }] })], DEFAULT_SETTINGS, { today: TODAY });
  assert.equal(r.eligible.length, 1);
});
